import React from 'react'

class FormSection extends React.PureComponent {
  state = {
    collapsed: !!this.props.defaultCollapsed,
  }

  toggleCollapsed = () => {
    const { collapsible } = this.props
    if (!collapsible) return
    this.setState(prevState => ({
      collapsed: !prevState.collapsed,
    }))
  }

  render() {
    const {
      title,
      extra,
      collapsible = false,
      style,
      className,
      children,
    } = this.props
    const { collapsed } = this.state

    return (
      <section
        className={className}
        style={{
          marginBottom: 24,
          padding: 16,
          border: '1px solid #f0f0f0',
          borderRadius: 4,
          background: '#fff',
          ...style,
        }}
      >
        {(title || extra) ? (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: collapsed ? 0 : 16,
            }}
          >
            <div
              onClick={this.toggleCollapsed}
              style={{
                fontSize: 16,
                fontWeight: 500,
                cursor: collapsible ? 'pointer' : 'default',
              }}
            >
              {title}
            </div>
            <div>{extra}</div>
          </div>
        ) : null}
        {collapsed ? null : children}
      </section>
    )
  }
}

export default FormSection
