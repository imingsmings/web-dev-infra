import React from 'react'
import { Form } from 'antd'
import FormContext from '../context/FormContext'

const FormItem = Form.Item

class VirtualField extends React.PureComponent {
  static contextType = FormContext

  getItemLayoutProps = () => {
    const {
      labelCol,
      wrapperCol,
    } = this.props
    const context = this.context || {}
    const layout = context.layout || 'horizontal'

    if (layout !== 'horizontal') {
      return {}
    }

    return {
      labelCol: labelCol || context.labelCol,
      wrapperCol: wrapperCol || context.wrapperCol,
    }
  }

  render() {
    const {
      name,
      label,
      required,
      help,
      validateStatus,
      extra,
      className,
      style,
      children,
    } = this.props
    const context = this.context || {}
    const extraError = name && context.getExtraError ? context.getExtraError(name) : undefined
    const mergedHelp = typeof help !== 'undefined' ? help : extraError
    const mergedValidateStatus = typeof validateStatus !== 'undefined'
      ? validateStatus
      : (extraError ? 'error' : undefined)

    return (
      <FormItem
        label={label}
        required={required}
        help={mergedHelp}
        extra={extra}
        validateStatus={mergedValidateStatus}
        className={className}
        style={style}
        {...this.getItemLayoutProps()}
      >
        {children}
      </FormItem>
    )
  }
}

export default VirtualField
