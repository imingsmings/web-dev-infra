import React from 'react'
import { Form, Select, Radio } from 'antd'
import FormContext from '../context/FormContext'
import { getFieldComponent as getGlobalFieldComponent } from '../core/fieldRegistry'
import { devWarning } from '../core/warnings'

const FormItem = Form.Item
const { Option } = Select

function buildRequiredRule({ label, message, component }) {
  const isSelectLike = [
    'select',
    'radioGroup',
    'checkboxGroup',
    'cascader',
    'datePicker',
    'monthPicker',
    'rangePicker',
    'timePicker',
  ].includes(component)

  return {
    required: true,
    message: message || `${isSelectLike ? '请选择' : '请输入'}${label}`,
  }
}

function buildRules(props) {
  const {
    label,
    rules = [],
    required,
    requiredMessage,
    component,
  } = props

  const nextRules = [...rules]

  if (required) {
    nextRules.unshift(buildRequiredRule({
      label,
      message: requiredMessage,
      component,
    }))
  }

  return nextRules
}

function getValuePropName(component, valuePropName) {
  if (valuePropName) return valuePropName

  if (component === 'switch' || component === 'checkbox') {
    return 'checked'
  }

  if (component === 'upload') {
    return 'fileList'
  }

  return 'value'
}

function normalizeOptions(options) {
  return Array.isArray(options) ? options : []
}

function getOptionLabel(options, value) {
  const matched = normalizeOptions(options).find(item => item.value === value)
  return matched ? matched.label : value
}

function findCascaderLabels(options, targetValues, collected = []) {
  if (!Array.isArray(targetValues) || !targetValues.length) return collected

  const [current, ...rest] = targetValues
  const currentOption = normalizeOptions(options).find(item => item.value === current)

  if (!currentOption) {
    return [...collected, current]
  }

  const nextCollected = [...collected, currentOption.label]
  if (!rest.length) return nextCollected

  return findCascaderLabels(currentOption.children || [], rest, nextCollected)
}

function formatMomentValue(value, format) {
  if (value && typeof value.format === 'function') {
    return value.format(format || 'YYYY-MM-DD HH:mm:ss')
  }
  return value
}

function defaultRenderControl(Comp, component, componentProps, options) {

  if (component === 'select') {
    return (
      <Comp {...componentProps}>
        {normalizeOptions(options).map(item => (
          <Option key={item.value} value={item.value} disabled={item.disabled}>
            {item.label}
          </Option>
        ))}
      </Comp>
    )
  }

  if (component === 'radioGroup') {
    return (
      <Comp {...componentProps}>
        {normalizeOptions(options).map(item => (
          <Radio key={item.value} value={item.value} disabled={item.disabled}>
            {item.label}
          </Radio>
        ))}
      </Comp>
    )
  }

  if (component === 'checkboxGroup') {
    return (
      <Comp
        options={normalizeOptions(options).map(item => ({
          label: item.label,
          value: item.value,
          disabled: item.disabled,
        }))}
        {...componentProps}
      />
    )
  }

  return <Comp {...componentProps} />
}

class FormField extends React.PureComponent {
  static contextType = FormContext

  getResolvedComponent = () => {
    const { component = 'input' } = this.props
    const context = this.context || {}

    if (typeof component !== 'string') {
      return component
    }

    const localFieldComponent = context.getFieldComponent
      ? context.getFieldComponent(component)
      : null

    return localFieldComponent || getGlobalFieldComponent(component) || component
  }

  getItemLayoutProps = () => {
    const {
      labelCol,
      wrapperCol,
      colon,
    } = this.props
    const context = this.context || {}
    const layout = context.layout || 'horizontal'

    const nextProps = {
      colon: typeof colon === 'undefined' ? context.colon : colon,
    }

    if (layout === 'horizontal') {
      nextProps.labelCol = labelCol || context.labelCol
      nextProps.wrapperCol = wrapperCol || context.wrapperCol
    }

    return nextProps
  }

  componentDidMount() {
    this.registerField()
    this.runPropWarnings()
    this.handleHiddenSideEffects(false, this.isHidden())
  }

  componentDidUpdate(prevProps) {
    if (prevProps.name !== this.props.name) {
      this.unregisterField(prevProps.name)
      this.registerField()
    }

    this.runPropWarnings()
    this.handleHiddenSideEffects(this.resolveStateValue(prevProps.hidden), this.isHidden())
  }

  componentWillUnmount() {
    this.unregisterField(this.props.name)
  }

  getFieldContext = () => {
    const context = this.context || {}
    return {
      form: context.form,
      values: context.getAllValues ? context.getAllValues() : {},
      disabled: !!context.disabled || !!context.submitting,
      readonly: !!context.readonly,
      submitting: !!context.submitting,
      valueVersion: context.valueVersion,
    }
  }

  getFieldMeta = () => {
    const {
      name,
      transform,
      component = 'input',
      clearOnHidden,
      preserveOnHidden,
    } = this.props

    return {
      name,
      transform,
      component,
      clearOnHidden,
      preserveOnHidden,
    }
  }

  shouldPreserveOnHidden = () => {
    const { clearOnHidden, preserveOnHidden } = this.props

    if (clearOnHidden) return false
    if (typeof preserveOnHidden === 'boolean') return preserveOnHidden
    return true
  }

  registerField = () => {
    const { name } = this.props
    const { registerField } = this.context || {}

    if (!name || !registerField) return
    registerField(name, this.getFieldMeta)
  }

  unregisterField = (name) => {
    const { unregisterField } = this.context || {}
    if (!name || !unregisterField) return
    unregisterField(name)
  }

  resolveStateValue = (value) => {
    if (typeof value !== 'function') return !!value
    return !!value(this.getFieldContext())
  }

  isHidden = () => this.resolveStateValue(this.props.hidden)

  isDisabled = () => this.resolveStateValue(this.props.disabled) || this.getFieldContext().disabled

  isReadonly = () => this.resolveStateValue(this.props.readonly) || this.getFieldContext().readonly

  handleHiddenSideEffects = (prevHidden, nextHidden) => {
    const { name } = this.props
    const { form } = this.getFieldContext()

    if (!name || !form) return
    if (prevHidden === nextHidden || !nextHidden) return
    if (this.shouldPreserveOnHidden()) return

    form.setFieldsValue({
      [name]: undefined,
    })
  }

  runPropWarnings = () => {
    const {
      name,
      component = 'input',
      options,
      initialValue,
      clearOnHidden,
      preserveOnHidden,
    } = this.props

    devWarning(!!name, 'FormField 缺少必填属性 name。', 'field-missing-name')
    const resolvedComponent = this.getResolvedComponent()
    devWarning(
      !!(resolvedComponent || typeof component === 'function' || typeof component === 'object'),
      `字段 "${name || 'unknown'}" 使用了未注册的 component: ${component}`,
      `field-component:${name}:${component}`
    )

    if (['select', 'radioGroup', 'checkboxGroup'].includes(component)) {
      devWarning(
        Array.isArray(options),
        `字段 "${name || 'unknown'}" 的 component="${component}" 时建议提供 options 数组。`,
        `field-options:${name}`
      )
    }

    if (component === 'switch' || component === 'checkbox') {
      devWarning(
        typeof initialValue === 'undefined' || typeof initialValue === 'boolean',
        `字段 "${name || 'unknown'}" 的 initialValue 应为 boolean。`,
        `field-boolean-initial:${name}`
      )
    }

    if (component === 'rangePicker') {
      devWarning(
        typeof initialValue === 'undefined' || Array.isArray(initialValue),
        `字段 "${name || 'unknown'}" 的 initialValue 应为数组。`,
        `field-range-initial:${name}`
      )
    }

    if (typeof preserveOnHidden !== 'undefined') {
      devWarning(
        typeof preserveOnHidden === 'boolean',
        `字段 "${name || 'unknown'}" 的 preserveOnHidden 应为 boolean。`,
        `field-hidden-preserve-type:${name}`
      )
    }
  }

  getDecoratorOptions = () => {
    const {
      initialValue,
      normalize,
      getValueFromEvent,
      validateFirst,
      validateTrigger,
      trigger,
      component,
      valuePropName,
    } = this.props

    const decoratorOptions = {
      initialValue,
      rules: buildRules(this.props),
      valuePropName: getValuePropName(component, valuePropName),
    }

    if (normalize) decoratorOptions.normalize = normalize
    if (getValueFromEvent) decoratorOptions.getValueFromEvent = getValueFromEvent
    if (typeof validateFirst !== 'undefined') decoratorOptions.validateFirst = validateFirst
    if (validateTrigger) decoratorOptions.validateTrigger = validateTrigger
    if (trigger) decoratorOptions.trigger = trigger

    return decoratorOptions
  }

  renderControlNode = () => {
    const {
      component = 'input',
      componentProps = {},
      options = [],
      renderControl,
      name,
    } = this.props
    const disabled = this.isDisabled()

    const mergedProps = {
      ...componentProps,
      disabled: typeof componentProps.disabled === 'undefined'
        ? disabled
        : componentProps.disabled,
      'data-field-name': name,
    }

    const renderArgs = {
      component,
      componentProps: mergedProps,
      options,
      form: this.getFieldContext().form,
      values: this.getFieldContext().values,
      disabled,
      readonly: this.isReadonly(),
    }

    const ResolvedComponent = this.getResolvedComponent()

    return renderControl
      ? renderControl(renderArgs)
      : defaultRenderControl(ResolvedComponent, component, mergedProps, options)
  }

  renderDecoratedControl = () => {
    const { form } = this.getFieldContext()
    const { name } = this.props

    if (!form || !name) return null

    return form.getFieldDecorator(name, this.getDecoratorOptions())(this.renderControlNode())
  }

  getDisplayValue = () => {
    const { name, initialValue } = this.props
    const { form, values } = this.getFieldContext()

    if (!name) return initialValue
    if (values && Object.prototype.hasOwnProperty.call(values, name)) {
      return values[name]
    }
    if (form) {
      const currentValue = form.getFieldValue(name)
      if (typeof currentValue !== 'undefined') {
        return currentValue
      }
    }

    return initialValue
  }

  renderReadonlyValue = () => {
    const {
      component = 'input',
      options = [],
      renderReadOnly,
      componentProps = {},
    } = this.props
    const { values } = this.getFieldContext()
    const value = this.getDisplayValue()

    if (typeof renderReadOnly === 'function') {
      return renderReadOnly({
        value,
        values,
        fieldProps: this.props,
      })
    }

    if (component === 'password') {
      return value ? '******' : '-'
    }

    if (component === 'select' || component === 'radioGroup') {
      return getOptionLabel(options, value) || '-'
    }

    if (component === 'checkboxGroup') {
      if (!Array.isArray(value) || !value.length) return '-'
      return value.map(item => getOptionLabel(options, item)).join('，')
    }

    if (component === 'checkbox' || component === 'switch') {
      return value ? '是' : '否'
    }

    if (component === 'cascader') {
      if (!Array.isArray(value) || !value.length) return '-'
      return findCascaderLabels(options, value).join(' / ')
    }

    if (component === 'rangePicker') {
      if (!Array.isArray(value) || !value.length) return '-'
      return value
        .map(item => formatMomentValue(item, componentProps.format))
        .join(' ~ ')
    }

    if (['datePicker', 'monthPicker', 'timePicker'].includes(component)) {
      const defaultFormatMap = {
        datePicker: 'YYYY-MM-DD',
        monthPicker: 'YYYY-MM',
        timePicker: 'HH:mm:ss',
      }
      return formatMomentValue(value, componentProps.format || defaultFormatMap[component]) || '-'
    }

    if (Array.isArray(value)) {
      return value.join('，') || '-'
    }

    if (component && typeof component !== 'string' && typeof renderReadOnly !== 'function') {
      return typeof value === 'undefined' || value === null || value === ''
        ? '-'
        : JSON.stringify(value)
    }

    return typeof value === 'undefined' || value === null || value === ''
      ? '-'
      : String(value)
  }

  renderReadonlyControl = () => (
    <>
      <div style={{ display: 'none' }}>
        {this.renderDecoratedControl()}
      </div>
      <div className="base-form-readonly-value">
        {this.renderReadonlyValue()}
      </div>
    </>
  )

  renderFieldContent = () => {
    if (this.isReadonly()) {
      return this.renderReadonlyControl()
    }

    return this.renderDecoratedControl()
  }

  render() {
    const {
      noStyle,
      label,
      extra,
      help,
      validateStatus,
      required,
      className,
      style,
    } = this.props
    const context = this.context || {}
    const hidden = this.isHidden()

    const content = this.renderFieldContent()

    if (noStyle) {
      return hidden ? <div style={{ display: 'none' }}>{content}</div> : content
    }

    return (
      <FormItem
        label={label}
        extra={extra}
        help={help}
        validateStatus={validateStatus}
        required={required}
        className={className}
        style={{
          display: hidden ? 'none' : undefined,
          ...style,
        }}
        {...this.getItemLayoutProps()}
      >
        {content}
      </FormItem>
    )
  }
}

export default FormField
