export function applyFieldTransforms(values, fieldMetas, form) {
  const nextValues = { ...values }

  Object.keys(fieldMetas).forEach((name) => {
    const meta = fieldMetas[name] || {}
    if (typeof meta.transform === 'function') {
      nextValues[name] = meta.transform(nextValues[name], nextValues, form)
    }
  })

  return nextValues
}
