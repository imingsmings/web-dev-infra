"use strict";(self.webpackChunkantd=self.webpackChunkantd||[]).push([[52764],{96598:function(d,s,r){r.r(s);var m=r(863942),u=r(502143),g=r(968521),y=r(702951),h=r(521587),j=r(199100),i=r(828089),v=r(825673),b=r(902068),x=r(574399),f=r(316073),k=r(24628),_=r(719260),C=r(956140),l=r(127179),c=r(905388),w=r(245583),D=r(606965),R=r(268696),E=r(587302),n=r(424128),z=r(249706),P=r(795127),q=r(116846),B=r(720538),A=r(212039),O=r(73024),M=r(553913),o=r(385956),T=r(667294),e=r(785893);function a(){var p=(0,o.useRouteMeta)(),t=p.texts;return(0,e.jsx)(o.DumiPage,{children:(0,e.jsxs)(e.Fragment,{children:[(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsx)("p",{children:t[0].value}),(0,e.jsxs)("h2",{id:"\u8BBE\u8BA1\u7406\u5FF5",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u8BBE\u8BA1\u7406\u5FF5",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u8BBE\u8BA1\u7406\u5FF5"]}),(0,e.jsxs)("div",{className:"grid-demo",children:[t[1].value,(0,e.jsx)("img",{src:"https://gw.alipayobjects.com/zos/bmw-prod/9189c9ef-c601-40dc-9960-c11dbb681888.svg",alt:"grid design"})]}),(0,e.jsx)("p",{children:t[2].value}),(0,e.jsx)("p",{children:t[3].value}),(0,e.jsxs)("h2",{id:"\u6982\u8FF0",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u6982\u8FF0",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u6982\u8FF0"]}),(0,e.jsx)("p",{children:t[4].value}),(0,e.jsxs)("ul",{children:[(0,e.jsxs)("li",{children:[t[5].value,(0,e.jsx)("code",{children:t[6].value}),t[7].value,(0,e.jsx)("code",{children:t[8].value}),t[9].value]}),(0,e.jsxs)("li",{children:[t[10].value,(0,e.jsx)("code",{children:t[11].value}),t[12].value,(0,e.jsx)("code",{children:t[13].value}),t[14].value,(0,e.jsx)("code",{children:t[15].value}),t[16].value]}),(0,e.jsxs)("li",{children:[t[17].value,(0,e.jsx)("code",{children:t[18].value}),t[19].value]}),(0,e.jsxs)("li",{children:[t[20].value,(0,e.jsx)("code",{children:t[21].value}),t[22].value,(0,e.jsx)("code",{children:t[23].value}),t[24].value,(0,e.jsx)("code",{children:t[25].value}),t[26].value]})]}),(0,e.jsx)("p",{children:t[27].value}),(0,e.jsx)("p",{children:t[28].value}),(0,e.jsxs)("h2",{id:"\u4EE3\u7801\u6F14\u793A",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4EE3\u7801\u6F14\u793A",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4EE3\u7801\u6F14\u793A"]})]}),(0,e.jsx)(c.Z,{items:[{demo:{id:"components-grid-demo-basic"},previewerProps:{title:"\u57FA\u7840\u6805\u683C",filename:"components/grid/demo/basic.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Row } from 'antd';
const App = () => (
  <>
    <Row>
      <Col span={24}>col</Col>
    </Row>
    <Row>
      <Col span={12}>col-12</Col>
      <Col span={12}>col-12</Col>
    </Row>
    <Row>
      <Col span={8}>col-8</Col>
      <Col span={8}>col-8</Col>
      <Col span={8}>col-8</Col>
    </Row>
    <Row>
      <Col span={6}>col-6</Col>
      <Col span={6}>col-6</Col>
      <Col span={6}>col-6</Col>
      <Col span={6}>col-6</Col>
    </Row>
  </>
);
export default App;
`,description:`<p>\u4ECE\u5806\u53E0\u5230\u6C34\u5E73\u6392\u5217\u3002</p>
<p>\u4F7F\u7528\u5355\u4E00\u7684\u4E00\u7EC4 <code>Row</code> \u548C <code>Col</code> \u6805\u683C\u7EC4\u4EF6\uFF0C\u5C31\u53EF\u4EE5\u521B\u5EFA\u4E00\u4E2A\u57FA\u672C\u7684\u6805\u683C\u7CFB\u7EDF\uFF0C\u6240\u6709\u5217\uFF08Col\uFF09\u5FC5\u987B\u653E\u5728 <code>Row</code> \u5185\u3002</p>`}},{demo:{id:"components-grid-demo-gutter"},previewerProps:{title:"\u533A\u5757\u95F4\u9694",filename:"components/grid/demo/gutter.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Divider, Row } from 'antd';
const style = {
  background: '#0092ff',
  padding: '8px 0',
};
const App = () => (
  <>
    <Divider orientation="left">Horizontal</Divider>
    <Row gutter={16}>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
    </Row>
    <Divider orientation="left">Responsive</Divider>
    <Row
      gutter={{
        xs: 8,
        sm: 16,
        md: 24,
        lg: 32,
      }}
    >
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
    </Row>
    <Divider orientation="left">Vertical</Divider>
    <Row gutter={[16, 24]}>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
      <Col className="gutter-row" span={6}>
        <div style={style}>col-6</div>
      </Col>
    </Row>
  </>
);
export default App;
`,description:`<p>\u6805\u683C\u5E38\u5E38\u9700\u8981\u548C\u95F4\u9694\u8FDB\u884C\u914D\u5408\uFF0C\u4F60\u53EF\u4EE5\u4F7F\u7528 <code>Row</code> \u7684 <code>gutter</code> \u5C5E\u6027\uFF0C\u6211\u4EEC\u63A8\u8350\u4F7F\u7528 <code>(16+8n)px</code> \u4F5C\u4E3A\u6805\u683C\u95F4\u9694(n \u662F\u81EA\u7136\u6570)\u3002</p>
<p>\u5982\u679C\u8981\u652F\u6301\u54CD\u5E94\u5F0F\uFF0C\u53EF\u4EE5\u5199\u6210 <code>{ xs: 8, sm: 16, md: 24, lg: 32 }</code>\u3002</p>
<p>\u5982\u679C\u9700\u8981\u5782\u76F4\u95F4\u8DDD\uFF0C\u53EF\u4EE5\u5199\u6210\u6570\u7EC4\u5F62\u5F0F <code>[\u6C34\u5E73\u95F4\u8DDD, \u5782\u76F4\u95F4\u8DDD]</code> <code>[16, { xs: 8, sm: 16, md: 24, lg: 32 }]</code>\u3002</p>
<blockquote>
<p>\u6570\u7EC4\u5F62\u5F0F\u5782\u76F4\u95F4\u8DDD\u5728 <code>3.24.0</code> \u4E4B\u540E\u652F\u6301\u3002</p>
</blockquote>`,style:`.gutter-box {
  padding: 8px 0;
  background: #00a0e9;
}`}},{demo:{id:"components-grid-demo-offset"},previewerProps:{title:"\u5DE6\u53F3\u504F\u79FB",filename:"components/grid/demo/offset.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Row } from 'antd';
const App = () => (
  <>
    <Row>
      <Col span={8}>col-8</Col>
      <Col span={8} offset={8}>
        col-8
      </Col>
    </Row>
    <Row>
      <Col span={6} offset={6}>
        col-6 col-offset-6
      </Col>
      <Col span={6} offset={6}>
        col-6 col-offset-6
      </Col>
    </Row>
    <Row>
      <Col span={12} offset={6}>
        col-12 col-offset-6
      </Col>
    </Row>
  </>
);
export default App;
`,description:`<p>\u5217\u504F\u79FB\u3002</p>
<p>\u4F7F\u7528 <code>offset</code> \u53EF\u4EE5\u5C06\u5217\u5411\u53F3\u4FA7\u504F\u3002\u4F8B\u5982\uFF0C<code>offset={4}</code> \u5C06\u5143\u7D20\u5411\u53F3\u4FA7\u504F\u79FB\u4E86 4 \u4E2A\u5217\uFF08column\uFF09\u7684\u5BBD\u5EA6\u3002</p>`}},{demo:{id:"components-grid-demo-sort"},previewerProps:{title:"\u6805\u683C\u6392\u5E8F",filename:"components/grid/demo/sort.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Row } from 'antd';
const App = () => (
  <Row>
    <Col span={18} push={6}>
      col-18 col-push-6
    </Col>
    <Col span={6} pull={18}>
      col-6 col-pull-18
    </Col>
  </Row>
);
export default App;
`,description:`<p>\u5217\u6392\u5E8F\u3002</p>
<p>\u901A\u8FC7\u4F7F\u7528 <code>push</code> \u548C <code>pull</code> \u7C7B\u5C31\u53EF\u4EE5\u5F88\u5BB9\u6613\u7684\u6539\u53D8\u5217\uFF08column\uFF09\u7684\u987A\u5E8F\u3002</p>`}},{demo:{id:"components-grid-demo-flex"},previewerProps:{title:"\u6392\u7248",filename:"components/grid/demo/flex.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Divider, Row } from 'antd';
const App = () => (
  <>
    <Divider orientation="left">sub-element align left</Divider>
    <Row justify="start">
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
    </Row>

    <Divider orientation="left">sub-element align center</Divider>
    <Row justify="center">
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
    </Row>

    <Divider orientation="left">sub-element align right</Divider>
    <Row justify="end">
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
    </Row>

    <Divider orientation="left">sub-element monospaced arrangement</Divider>
    <Row justify="space-between">
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
    </Row>

    <Divider orientation="left">sub-element align full</Divider>
    <Row justify="space-around">
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
    </Row>

    <Divider orientation="left">sub-element align evenly</Divider>
    <Row justify="space-evenly">
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
      <Col span={4}>col-4</Col>
    </Row>
  </>
);
export default App;
`,description:`<p>\u5E03\u5C40\u57FA\u7840\u3002</p>
<p>\u5B50\u5143\u7D20\u6839\u636E\u4E0D\u540C\u7684\u503C <code>start</code>\u3001<code>center</code>\u3001<code>end</code>\u3001<code>space-between</code>\u3001<code>space-around</code> \u548C <code>space-evenly</code>\uFF0C\u5206\u522B\u5B9A\u4E49\u5176\u5728\u7236\u8282\u70B9\u91CC\u9762\u7684\u6392\u7248\u65B9\u5F0F\u3002</p>`,style:`#components-grid-demo-flex [class~='ant-row'] {
  background: rgba(128, 128, 128, 0.08);
}`}},{demo:{id:"components-grid-demo-flex-align"},previewerProps:{title:"\u5BF9\u9F50",filename:"components/grid/demo/flex-align.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Divider, Row } from 'antd';
const DemoBox = (props) => <p className={\`height-\${props.value}\`}>{props.children}</p>;
const App = () => (
  <>
    <Divider orientation="left">Align Top</Divider>
    <Row justify="center" align="top">
      <Col span={4}>
        <DemoBox value={100}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={50}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={120}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={80}>col-4</DemoBox>
      </Col>
    </Row>

    <Divider orientation="left">Align Middle</Divider>
    <Row justify="space-around" align="middle">
      <Col span={4}>
        <DemoBox value={100}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={50}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={120}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={80}>col-4</DemoBox>
      </Col>
    </Row>

    <Divider orientation="left">Align Bottom</Divider>
    <Row justify="space-between" align="bottom">
      <Col span={4}>
        <DemoBox value={100}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={50}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={120}>col-4</DemoBox>
      </Col>
      <Col span={4}>
        <DemoBox value={80}>col-4</DemoBox>
      </Col>
    </Row>
  </>
);
export default App;
`,description:"<p>\u5B50\u5143\u7D20\u5782\u76F4\u5BF9\u9F50\u3002</p>",style:`#components-grid-demo-flex-align [class~='ant-row'] {
  background: rgba(128, 128, 128, 0.08);
}`}},{demo:{id:"components-grid-demo-flex-order"},previewerProps:{title:"\u6392\u5E8F",filename:"components/grid/demo/flex-order.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Divider, Row } from 'antd';
const App = () => (
  <>
    <Divider orientation="left">Normal</Divider>
    <Row>
      <Col span={6} order={4}>
        1 col-order-4
      </Col>
      <Col span={6} order={3}>
        2 col-order-3
      </Col>
      <Col span={6} order={2}>
        3 col-order-2
      </Col>
      <Col span={6} order={1}>
        4 col-order-1
      </Col>
    </Row>
    <Divider orientation="left">Responsive</Divider>
    <Row>
      <Col
        span={6}
        xs={{
          order: 1,
        }}
        sm={{
          order: 2,
        }}
        md={{
          order: 3,
        }}
        lg={{
          order: 4,
        }}
      >
        1 col-order-responsive
      </Col>
      <Col
        span={6}
        xs={{
          order: 2,
        }}
        sm={{
          order: 1,
        }}
        md={{
          order: 4,
        }}
        lg={{
          order: 3,
        }}
      >
        2 col-order-responsive
      </Col>
      <Col
        span={6}
        xs={{
          order: 3,
        }}
        sm={{
          order: 4,
        }}
        md={{
          order: 2,
        }}
        lg={{
          order: 1,
        }}
      >
        3 col-order-responsive
      </Col>
      <Col
        span={6}
        xs={{
          order: 4,
        }}
        sm={{
          order: 3,
        }}
        md={{
          order: 1,
        }}
        lg={{
          order: 2,
        }}
      >
        4 col-order-responsive
      </Col>
    </Row>
  </>
);
export default App;
`,description:"<p>\u901A\u8FC7 <code>order</code> \u6765\u6539\u53D8\u5143\u7D20\u7684\u6392\u5E8F\u3002</p>",style:`#components-grid-demo-flex-order [class~='ant-row'] {
  background: rgba(128, 128, 128, 0.08);
}`}},{demo:{id:"components-grid-demo-flex-stretch"},previewerProps:{title:"Flex \u586B\u5145",filename:"components/grid/demo/flex-stretch.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Divider, Row } from 'antd';
const App = () => (
  <>
    <Divider orientation="left">Percentage columns</Divider>
    <Row>
      <Col flex={2}>2 / 5</Col>
      <Col flex={3}>3 / 5</Col>
    </Row>
    <Divider orientation="left">Fill rest</Divider>
    <Row>
      <Col flex="100px">100px</Col>
      <Col flex="auto">Fill Rest</Col>
    </Row>
    <Divider orientation="left">Raw flex style</Divider>
    <Row>
      <Col flex="1 1 200px">1 1 200px</Col>
      <Col flex="0 1 300px">0 1 300px</Col>
    </Row>

    <Row wrap={false}>
      <Col flex="none">
        <div
          style={{
            padding: '0 16px',
          }}
        >
          none
        </div>
      </Col>
      <Col flex="auto">auto with no-wrap</Col>
    </Row>
  </>
);
export default App;
`,description:"<p>Col \u63D0\u4F9B <code>flex</code> \u5C5E\u6027\u4EE5\u652F\u6301\u586B\u5145\u3002</p>"}},{demo:{id:"components-grid-demo-responsive"},previewerProps:{title:"\u54CD\u5E94\u5F0F\u5E03\u5C40",filename:"components/grid/demo/responsive.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Row } from 'antd';
const App = () => (
  <Row>
    <Col xs={2} sm={4} md={6} lg={8} xl={10}>
      Col
    </Col>
    <Col xs={20} sm={16} md={12} lg={8} xl={4}>
      Col
    </Col>
    <Col xs={2} sm={4} md={6} lg={8} xl={10}>
      Col
    </Col>
  </Row>
);
export default App;
`,description:'<p>\u53C2\u7167 Bootstrap \u7684 <a href="http://getbootstrap.com/css/#grid-media-queries">\u54CD\u5E94\u5F0F\u8BBE\u8BA1</a>\uFF0C\u9884\u8BBE\u516D\u4E2A\u54CD\u5E94\u5C3A\u5BF8\uFF1A<code>xs</code> <code>sm</code> <code>md</code> <code>lg</code> <code>xl</code> <code>xxl</code>\u3002</p>'}},{demo:{id:"components-grid-demo-responsive-more"},previewerProps:{title:"\u5176\u4ED6\u5C5E\u6027\u7684\u54CD\u5E94\u5F0F",filename:"components/grid/demo/responsive-more.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Col, Row } from 'antd';
const App = () => (
  <Row>
    <Col
      xs={{
        span: 5,
        offset: 1,
      }}
      lg={{
        span: 6,
        offset: 2,
      }}
    >
      Col
    </Col>
    <Col
      xs={{
        span: 11,
        offset: 1,
      }}
      lg={{
        span: 6,
        offset: 2,
      }}
    >
      Col
    </Col>
    <Col
      xs={{
        span: 5,
        offset: 1,
      }}
      lg={{
        span: 6,
        offset: 2,
      }}
    >
      Col
    </Col>
  </Row>
);
export default App;
`,description:`<p><code>span</code> <code>pull</code> <code>push</code> <code>offset</code> <code>order</code> \u5C5E\u6027\u53EF\u4EE5\u901A\u8FC7\u5185\u5D4C\u5230 <code>xs</code> <code>sm</code> <code>md</code> <code>lg</code> <code>xl</code> <code>xxl</code> \u5C5E\u6027\u4E2D\u6765\u4F7F\u7528\u3002</p>
<p>\u5176\u4E2D <code>xs={6}</code> \u76F8\u5F53\u4E8E <code>xs={{ span: 6 }}</code>\u3002</p>`}},{demo:{id:"components-grid-demo-playground"},previewerProps:{title:"\u6805\u683C\u914D\u7F6E\u5668",filename:"components/grid/demo/playground.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { Col, Row, Slider } from 'antd';
const gutters = {};
const vgutters = {};
const colCounts = {};
[8, 16, 24, 32, 40, 48].forEach((value, i) => {
  gutters[i] = value;
});
[8, 16, 24, 32, 40, 48].forEach((value, i) => {
  vgutters[i] = value;
});
[2, 3, 4, 6, 8, 12].forEach((value, i) => {
  colCounts[i] = value;
});
const App = () => {
  const [gutterKey, setGutterKey] = useState(1);
  const [vgutterKey, setVgutterKey] = useState(1);
  const [colCountKey, setColCountKey] = useState(2);
  const cols = [];
  const colCount = colCounts[colCountKey];
  let colCode = '';
  for (let i = 0; i < colCount; i++) {
    cols.push(
      <Col key={i.toString()} span={24 / colCount}>
        <div>Column</div>
      </Col>,
    );
    colCode += \`  <Col span={\${24 / colCount}} />\\n\`;
  }
  return (
    <>
      <span>Horizontal Gutter (px): </span>
      <div
        style={{
          width: '50%',
        }}
      >
        <Slider
          min={0}
          max={Object.keys(gutters).length - 1}
          value={gutterKey}
          onChange={setGutterKey}
          marks={gutters}
          step={null}
          tooltip={{
            formatter: (value) => gutters[value],
          }}
        />
      </div>
      <span>Vertical Gutter (px): </span>
      <div
        style={{
          width: '50%',
        }}
      >
        <Slider
          min={0}
          max={Object.keys(vgutters).length - 1}
          value={vgutterKey}
          onChange={setVgutterKey}
          marks={vgutters}
          step={null}
          tooltip={{
            formatter: (value) => vgutters[value],
          }}
        />
      </div>
      <span>Column Count:</span>
      <div
        style={{
          width: '50%',
          marginBottom: 48,
        }}
      >
        <Slider
          min={0}
          max={Object.keys(colCounts).length - 1}
          value={colCountKey}
          onChange={setColCountKey}
          marks={colCounts}
          step={null}
          tooltip={{
            formatter: (value) => colCounts[value],
          }}
        />
      </div>
      <Row gutter={[gutters[gutterKey], vgutters[vgutterKey]]}>
        {cols}
        {cols}
      </Row>
      Another Row:
      <Row gutter={[gutters[gutterKey], vgutters[vgutterKey]]}>{cols}</Row>
      <pre className="demo-code">{\`<Row gutter={[\${gutters[gutterKey]}, \${vgutters[vgutterKey]}]}>\\n\${colCode}\\n\${colCode}</Row>\`}</pre>
      <pre className="demo-code">{\`<Row gutter={[\${gutters[gutterKey]}, \${vgutters[vgutterKey]}]}>\\n\${colCode}</Row>\`}</pre>
    </>
  );
};
export default App;
`,description:"<p>\u53EF\u4EE5\u7B80\u5355\u914D\u7F6E\u51E0\u79CD\u7B49\u5206\u6805\u683C\u548C\u95F4\u8DDD\u3002</p>",style:`#components-grid-demo-playground [class~='ant-col'] {
  background: transparent;
  border: 0;
}
#components-grid-demo-playground [class~='ant-col'] > div {
  height: 120px;
  font-size: 14px;
  line-height: 120px;
  background: #0092ff;
  border-radius: 4px;
}
#components-grid-demo-playground pre {
  padding: 8px 16px;
  font-size: 13px;
  background: #f9f9f9;
  border-radius: 6px;
}
#components-grid-demo-playground pre.demo-code {
  direction: ltr;
}
#components-grid-demo-playground .ant-col {
  padding: 0;
}`}},{demo:{id:"components-grid-demo-usebreakpoint"},previewerProps:{title:"useBreakpoint Hook",filename:"components/grid/demo/useBreakpoint.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Grid, Tag } from 'antd';
const { useBreakpoint } = Grid;
const App = () => {
  const screens = useBreakpoint();
  return (
    <>
      Current break point:{' '}
      {Object.entries(screens)
        .filter((screen) => !!screen[1])
        .map((screen) => (
          <Tag color="blue" key={screen[0]}>
            {screen[0]}
          </Tag>
        ))}
    </>
  );
};
export default App;
`,description:"<p>\u4F7F\u7528 <code>useBreakpoint</code> Hook \u4E2A\u6027\u5316\u5E03\u5C40\u3002</p>"}}]}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"api",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#api",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"API"]}),(0,e.jsxs)("p",{children:[t[29].value,(0,e.jsx)(n.Z,{to:"/docs/react/common-props",sourceType:"Link",children:t[30].value})]}),(0,e.jsx)("p",{children:t[31].value}),(0,e.jsxs)("ul",{children:[(0,e.jsx)("li",{children:(0,e.jsx)(n.Z,{href:"http://roylee0704.github.io/react-flexbox-grid/",sourceType:"a",children:t[32].value})}),(0,e.jsx)("li",{children:(0,e.jsx)(n.Z,{href:"https://github.com/whoisandy/react-blocks/",sourceType:"a",children:t[33].value})})]}),(0,e.jsxs)("h3",{id:"row",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#row",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Row"]}),(0,e.jsxs)(i.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[34].value}),(0,e.jsx)("th",{children:t[35].value}),(0,e.jsx)("th",{children:t[36].value}),(0,e.jsx)("th",{children:t[37].value}),(0,e.jsx)("th",{children:t[38].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[39].value}),(0,e.jsx)("td",{children:t[40].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[41].value}),t[42].value,(0,e.jsx)("code",{children:t[43].value}),t[44].value,(0,e.jsx)("code",{children:t[45].value}),t[46].value,(0,e.jsx)("code",{children:t[47].value}),t[48].value,(0,e.jsx)("code",{children:t[49].value})]}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[50].value})}),(0,e.jsx)("td",{children:t[51].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[52].value}),(0,e.jsxs)("td",{children:[t[53].value,(0,e.jsx)("code",{children:t[54].value})]}),(0,e.jsx)("td",{children:t[55].value}),(0,e.jsx)("td",{children:t[56].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[57].value}),(0,e.jsx)("td",{children:t[58].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[59].value}),t[60].value,(0,e.jsx)("code",{children:t[61].value}),t[62].value,(0,e.jsx)("code",{children:t[63].value}),t[64].value,(0,e.jsx)("code",{children:t[65].value}),t[66].value,(0,e.jsx)("code",{children:t[67].value}),t[68].value,(0,e.jsx)("code",{children:t[69].value}),t[70].value,(0,e.jsx)("code",{children:t[71].value})]}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[72].value})}),(0,e.jsx)("td",{children:t[73].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[74].value}),(0,e.jsx)("td",{children:t[75].value}),(0,e.jsx)("td",{children:t[76].value}),(0,e.jsx)("td",{children:t[77].value}),(0,e.jsx)("td",{children:t[78].value})]})]})]}),(0,e.jsxs)("h3",{id:"col",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#col",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Col"]}),(0,e.jsxs)(i.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[79].value}),(0,e.jsx)("th",{children:t[80].value}),(0,e.jsx)("th",{children:t[81].value}),(0,e.jsx)("th",{children:t[82].value}),(0,e.jsx)("th",{children:t[83].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[84].value}),(0,e.jsx)("td",{children:t[85].value}),(0,e.jsx)("td",{children:t[86].value}),(0,e.jsx)("td",{children:t[87].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[88].value}),(0,e.jsx)("td",{children:t[89].value}),(0,e.jsx)("td",{children:t[90].value}),(0,e.jsx)("td",{children:t[91].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[92].value}),(0,e.jsx)("td",{children:t[93].value}),(0,e.jsx)("td",{children:t[94].value}),(0,e.jsx)("td",{children:t[95].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[96].value}),(0,e.jsx)("td",{children:t[97].value}),(0,e.jsx)("td",{children:t[98].value}),(0,e.jsx)("td",{children:t[99].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[100].value}),(0,e.jsx)("td",{children:t[101].value}),(0,e.jsx)("td",{children:t[102].value}),(0,e.jsx)("td",{children:t[103].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[104].value}),(0,e.jsxs)("td",{children:[t[105].value,(0,e.jsx)("code",{children:t[106].value})]}),(0,e.jsx)("td",{children:t[107].value}),(0,e.jsx)("td",{children:t[108].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[109].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[110].value}),t[111].value]}),(0,e.jsx)("td",{children:t[112].value}),(0,e.jsx)("td",{children:t[113].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[114].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[115].value}),t[116].value]}),(0,e.jsx)("td",{children:t[117].value}),(0,e.jsx)("td",{children:t[118].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[119].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[120].value}),t[121].value]}),(0,e.jsx)("td",{children:t[122].value}),(0,e.jsx)("td",{children:t[123].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[124].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[125].value}),t[126].value]}),(0,e.jsx)("td",{children:t[127].value}),(0,e.jsx)("td",{children:t[128].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[129].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[130].value}),t[131].value]}),(0,e.jsx)("td",{children:t[132].value}),(0,e.jsx)("td",{children:t[133].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[134].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[135].value}),t[136].value]}),(0,e.jsx)("td",{children:t[137].value}),(0,e.jsx)("td",{children:t[138].value}),(0,e.jsx)("td",{})]})]})]}),(0,e.jsxs)("p",{children:[t[139].value,(0,e.jsx)(n.Z,{to:"/docs/react/customize-theme-cn",sourceType:"Link",children:t[140].value}),t[141].value,(0,e.jsx)("code",{children:t[142].value}),t[143].value,(0,e.jsx)(n.Z,{href:"https://codesandbox.io/s/antd-reproduction-template-forked-dlq3r9?file=/index.js",sourceType:"a",children:t[144].value}),t[145].value]}),(0,e.jsxs)("p",{children:[t[146].value,(0,e.jsx)(n.Z,{href:"https://getbootstrap.com/docs/4.0/layout/overview/#responsive-breakpoints",sourceType:"a",children:t[147].value}),t[148].value,(0,e.jsx)("code",{children:t[149].value}),t[150].value]}),(0,e.jsxs)("h2",{id:"\u4E3B\u9898\u53D8\u91CFdesign-token",children:[(0,e.jsx)(n.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4E3B\u9898\u53D8\u91CFdesign-token",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4E3B\u9898\u53D8\u91CF\uFF08Design Token\uFF09"]})]}),(0,e.jsx)(l.Z,{component:"Grid"})]})})}s.default=a}}]);
