"use strict";(self.webpackChunkantd=self.webpackChunkantd||[]).push([[54147],{164889:function(d,s,n){n.r(s);var m=n(863942),u=n(502143),g=n(968521),h=n(702951),y=n(521587),j=n(199100),i=n(828089),x=n(825673),b=n(902068),v=n(574399),k=n(316073),_=n(24628),f=n(719260),w=n(956140),a=n(127179),c=n(905388),C=n(245583),A=n(606965),P=n(268696),I=n(587302),r=n(424128),O=n(249706),z=n(795127),E=n(116846),D=n(720538),T=n(212039),S=n(73024),q=n(553913),o=n(385956),U=n(667294),e=n(785893);function l(){var p=(0,o.useRouteMeta)(),t=p.texts;return(0,e.jsx)(o.DumiPage,{children:(0,e.jsxs)(e.Fragment,{children:[(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsx)("p",{children:t[0].value}),(0,e.jsxs)("h2",{id:"when-to-use",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#when-to-use",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"When To Use"]}),(0,e.jsxs)("ul",{children:[(0,e.jsx)("li",{children:t[1].value}),(0,e.jsx)("li",{children:t[2].value})]}),(0,e.jsx)("p",{children:t[3].value}),(0,e.jsxs)("ul",{children:[(0,e.jsxs)("li",{children:[t[4].value,(0,e.jsx)("strong",{children:t[5].value}),t[6].value]}),(0,e.jsxs)("li",{children:[t[7].value,(0,e.jsx)("strong",{children:t[8].value}),t[9].value]})]}),(0,e.jsxs)("h2",{id:"examples",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#examples",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Examples"]})]}),(0,e.jsx)(c.Z,{items:[{demo:{id:"auto-complete-demo-basic"},previewerProps:{title:"Basic Usage",filename:"components/auto-complete/demo/basic.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { AutoComplete } from 'antd';
const mockVal = (str, repeat = 1) => ({
  value: str.repeat(repeat),
});
const App = () => {
  const [value, setValue] = useState('');
  const [options, setOptions] = useState([]);
  const [anotherOptions, setAnotherOptions] = useState([]);
  const getPanelValue = (searchText) =>
    !searchText ? [] : [mockVal(searchText), mockVal(searchText, 2), mockVal(searchText, 3)];
  const onSelect = (data) => {
    console.log('onSelect', data);
  };
  const onChange = (data) => {
    setValue(data);
  };
  return (
    <>
      <AutoComplete
        options={options}
        style={{
          width: 200,
        }}
        onSelect={onSelect}
        onSearch={(text) => setOptions(getPanelValue(text))}
        placeholder="input here"
      />
      <br />
      <br />
      <AutoComplete
        value={value}
        options={anotherOptions}
        style={{
          width: 200,
        }}
        onSelect={onSelect}
        onSearch={(text) => setAnotherOptions(getPanelValue(text))}
        onChange={onChange}
        placeholder="control mode"
      />
    </>
  );
};
export default App;
`,description:"<p>Basic Usage, set data source of autocomplete with <code>options</code> property.</p>"}},{demo:{id:"auto-complete-demo-options"},previewerProps:{title:"Customized",filename:"components/auto-complete/demo/options.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { AutoComplete } from 'antd';
const App = () => {
  const [options, setOptions] = useState([]);
  const handleSearch = (value) => {
    let res = [];
    if (!value || value.indexOf('@') >= 0) {
      res = [];
    } else {
      res = ['gmail.com', '163.com', 'qq.com'].map((domain) => ({
        value,
        label: \`\${value}@\${domain}\`,
      }));
    }
    setOptions(res);
  };
  return (
    <AutoComplete
      style={{
        width: 200,
      }}
      onSearch={handleSearch}
      placeholder="input here"
      options={options}
    />
  );
};
export default App;
`,description:"<p>You could set custom <code>Option</code> label</p>"}},{demo:{id:"auto-complete-demo-custom"},previewerProps:{title:"Customize Input Component",filename:"components/auto-complete/demo/custom.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { AutoComplete, Input } from 'antd';
const { TextArea } = Input;
const App = () => {
  const [options, setOptions] = useState([]);
  const handleSearch = (value) => {
    setOptions(
      !value
        ? []
        : [
            {
              value,
            },
            {
              value: value + value,
            },
            {
              value: value + value + value,
            },
          ],
    );
  };
  const handleKeyPress = (ev) => {
    console.log('handleKeyPress', ev);
  };
  const onSelect = (value) => {
    console.log('onSelect', value);
  };
  return (
    <AutoComplete
      options={options}
      style={{
        width: 200,
      }}
      onSelect={onSelect}
      onSearch={handleSearch}
    >
      <TextArea
        placeholder="input here"
        className="custom"
        style={{
          height: 50,
        }}
        onKeyPress={handleKeyPress}
      />
    </AutoComplete>
  );
};
export default App;
`,description:"<p>Customize Input Component</p>"}},{demo:{id:"auto-complete-demo-non-case-sensitive"},previewerProps:{title:"Non-case-sensitive AutoComplete",filename:"components/auto-complete/demo/non-case-sensitive.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { AutoComplete } from 'antd';
const options = [
  {
    value: 'Burns Bay Road',
  },
  {
    value: 'Downing Street',
  },
  {
    value: 'Wall Street',
  },
];
const App = () => (
  <AutoComplete
    style={{
      width: 200,
    }}
    options={options}
    placeholder="try to type \`b\`"
    filterOption={(inputValue, option) =>
      option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
    }
  />
);
export default App;
`,description:"<p>A non-case-sensitive AutoComplete</p>"}},{demo:{id:"auto-complete-demo-certain-category"},previewerProps:{title:"Lookup-Patterns - Certain Category",filename:"components/auto-complete/demo/certain-category.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UserOutlined } from '@ant-design/icons';
import { AutoComplete, Input } from 'antd';
const renderTitle = (title) => (
  <span>
    {title}
    <a
      style={{
        float: 'right',
      }}
      href="https://www.google.com/search?q=antd"
      target="_blank"
      rel="noopener noreferrer"
    >
      more
    </a>
  </span>
);
const renderItem = (title, count) => ({
  value: title,
  label: (
    <div
      style={{
        display: 'flex',
        justifyContent: 'space-between',
      }}
    >
      {title}
      <span>
        <UserOutlined /> {count}
      </span>
    </div>
  ),
});
const options = [
  {
    label: renderTitle('Libraries'),
    options: [renderItem('AntDesign', 10000), renderItem('AntDesign UI', 10600)],
  },
  {
    label: renderTitle('Solutions'),
    options: [renderItem('AntDesign UI FAQ', 60100), renderItem('AntDesign FAQ', 30010)],
  },
  {
    label: renderTitle('Articles'),
    options: [renderItem('AntDesign design language', 100000)],
  },
];
const App = () => (
  <AutoComplete
    popupClassName="certain-category-search-dropdown"
    popupMatchSelectWidth={500}
    style={{
      width: 250,
    }}
    options={options}
    size="large"
  >
    <Input.Search size="large" placeholder="input here" />
  </AutoComplete>
);
export default App;
`,description:'<p>Demonstration of <a href="https://ant.design/docs/spec/reaction#lookup-patterns">Lookup Patterns: Certain Category</a>. Basic Usage, set options of autocomplete with <code>options</code> property.</p>',style:`.certain-category-search-dropdown .ant-select-dropdown-menu-item-group-title {
  color: #666;
  font-weight: bold;
}

.certain-category-search-dropdown .ant-select-dropdown-menu-item-group {
  border-bottom: 1px solid #f6f6f6;
}

.certain-category-search-dropdown .ant-select-dropdown-menu-item {
  padding-left: 16px;
}

.certain-category-search-dropdown .ant-select-dropdown-menu-item.show-all {
  text-align: center;
  cursor: default;
}

.certain-category-search-dropdown .ant-select-dropdown-menu {
  max-height: 300px;
}`}},{demo:{id:"auto-complete-demo-uncertain-category"},previewerProps:{title:"Lookup-Patterns - Uncertain Category",filename:"components/auto-complete/demo/uncertain-category.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { AutoComplete, Input } from 'antd';
const getRandomInt = (max, min = 0) => Math.floor(Math.random() * (max - min + 1)) + min;
const searchResult = (query) =>
  new Array(getRandomInt(5))
    .join('.')
    .split('.')
    .map((_, idx) => {
      const category = \`\${query}\${idx}\`;
      return {
        value: category,
        label: (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
            }}
          >
            <span>
              Found {query} on{' '}
              <a
                href={\`https://s.taobao.com/search?q=\${query}\`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {category}
              </a>
            </span>
            <span>{getRandomInt(200, 100)} results</span>
          </div>
        ),
      };
    });
const App = () => {
  const [options, setOptions] = useState([]);
  const handleSearch = (value) => {
    setOptions(value ? searchResult(value) : []);
  };
  const onSelect = (value) => {
    console.log('onSelect', value);
  };
  return (
    <AutoComplete
      popupMatchSelectWidth={252}
      style={{
        width: 300,
      }}
      options={options}
      onSelect={onSelect}
      onSearch={handleSearch}
      size="large"
    >
      <Input.Search size="large" placeholder="input here" enterButton />
    </AutoComplete>
  );
};
export default App;
`,description:'<p>Demonstration of <a href="https://ant.design/docs/spec/reaction#lookup-patterns">Lookup Patterns: Uncertain Category</a>.</p>'}},{demo:{id:"auto-complete-demo-status"},previewerProps:{title:"Status",filename:"components/auto-complete/demo/status.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { AutoComplete, Space } from 'antd';
const mockVal = (str, repeat = 1) => ({
  value: str.repeat(repeat),
});
const App = () => {
  const [options, setOptions] = useState([]);
  const [anotherOptions, setAnotherOptions] = useState([]);
  const getPanelValue = (searchText) =>
    !searchText ? [] : [mockVal(searchText), mockVal(searchText, 2), mockVal(searchText, 3)];
  return (
    <Space
      direction="vertical"
      style={{
        width: '100%',
      }}
    >
      <AutoComplete
        options={options}
        onSearch={(text) => setOptions(getPanelValue(text))}
        status="error"
        style={{
          width: 200,
        }}
      />
      <AutoComplete
        options={anotherOptions}
        onSearch={(text) => setAnotherOptions(getPanelValue(text))}
        status="warning"
        style={{
          width: 200,
        }}
      />
    </Space>
  );
};
export default App;
`,description:"<p>Add status to AutoComplete with <code>status</code>, which could be <code>error</code> or <code>warning</code>.</p>"}},{demo:{id:"auto-complete-demo-borderless"},previewerProps:{title:"Borderless",filename:"components/auto-complete/demo/borderless.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { AutoComplete } from 'antd';
const mockVal = (str, repeat = 1) => ({
  value: str.repeat(repeat),
});
const App = () => {
  const [options, setOptions] = useState([]);
  const getPanelValue = (searchText) =>
    !searchText ? [] : [mockVal(searchText), mockVal(searchText, 2), mockVal(searchText, 3)];
  return (
    <AutoComplete
      options={options}
      style={{
        width: 200,
      }}
      placeholder="Borderless"
      onSearch={(text) => setOptions(getPanelValue(text))}
      onSelect={globalThis.console.log}
      bordered={false}
    />
  );
};
export default App;
`,description:"<p>No border.</p>"}},{demo:{id:"auto-complete-demo-allowclear"},previewerProps:{title:"Customize clear button",filename:"components/auto-complete/demo/allowClear.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { CloseSquareFilled } from '@ant-design/icons';
import { AutoComplete } from 'antd';
const mockVal = (str, repeat = 1) => ({
  value: str.repeat(repeat),
});
const App = () => {
  const [options, setOptions] = useState([]);
  const getPanelValue = (searchText) =>
    !searchText ? [] : [mockVal(searchText), mockVal(searchText, 2), mockVal(searchText, 3)];
  return (
    <>
      <AutoComplete
        options={options}
        style={{
          width: 200,
        }}
        onSearch={(text) => setOptions(getPanelValue(text))}
        placeholder="UnClearable"
        allowClear={false}
      />
      <br />
      <br />
      <AutoComplete
        options={options}
        style={{
          width: 200,
        }}
        onSearch={(text) => setOptions(getPanelValue(text))}
        placeholder="Customized clear icon"
        allowClear={{
          clearIcon: <CloseSquareFilled />,
        }}
      />
    </>
  );
};
export default App;
`,description:"<p>Customize clear button</p>"}},{demo:{id:"auto-complete-demo-form-debug"},previewerProps:{debug:!0,title:"Debug in Form",filename:"components/auto-complete/demo/form-debug.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { SearchOutlined } from '@ant-design/icons';
import { AutoComplete, Button, Form, Input, TreeSelect } from 'antd';
const formItemLayout = {
  labelCol: {
    xs: {
      span: 24,
    },
    sm: {
      span: 8,
    },
  },
  wrapperCol: {
    xs: {
      span: 24,
    },
    sm: {
      span: 16,
    },
  },
};
const App = () => (
  <Form
    style={{
      margin: '0 auto',
    }}
    {...formItemLayout}
  >
    <Form.Item label="\u5355\u72EC AutoComplete">
      <AutoComplete />
    </Form.Item>
    <Form.Item label="\u5355\u72EC TreeSelect">
      <TreeSelect />
    </Form.Item>
    <Form.Item label="\u6DFB\u52A0 Input.Group \u6B63\u5E38">
      <Input.Group compact>
        <TreeSelect
          style={{
            width: '30%',
          }}
        />
        <AutoComplete />
      </Input.Group>
    </Form.Item>
    <Form.Item label="\u5305\u542B search \u56FE\u6807\u6B63\u5E38">
      <AutoComplete>
        <Input suffix={<SearchOutlined />} />
      </AutoComplete>
    </Form.Item>
    <Form.Item label="\u540C\u65F6\u6709 Input.Group \u548C\u56FE\u6807\u53D1\u751F\u79FB\u4F4D">
      <Input.Group compact>
        <TreeSelect
          style={{
            width: '30%',
          }}
        />
        <AutoComplete>
          <Input suffix={<SearchOutlined />} />
        </AutoComplete>
      </Input.Group>
    </Form.Item>
    <Form.Item label="\u540C\u65F6\u6709 Input.Group \u548C Search \u7EC4\u4EF6\u53D1\u751F\u79FB\u4F4D">
      <Input.Group compact>
        <TreeSelect
          style={{
            width: '30%',
          }}
        />
        <AutoComplete>
          <Input.Search />
        </AutoComplete>
      </Input.Group>
    </Form.Item>
    <Form.Item label="Input Group \u548C Button \u7ED3\u5408">
      <Input.Group compact>
        <TreeSelect
          style={{
            width: '20%',
          }}
        />
        <AutoComplete>
          <Input.Search />
        </AutoComplete>
        <Button type="primary" icon={<SearchOutlined />}>
          Search
        </Button>
      </Input.Group>
    </Form.Item>
  </Form>
);
export default App;
`}},{demo:{id:"auto-complete-demo-render-panel"},previewerProps:{debug:!0,title:"_InternalPanelDoNotUseOrYouWillBeFired",filename:"components/auto-complete/demo/render-panel.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { AutoComplete, Switch, Space } from 'antd';
const { _InternalPanelDoNotUseOrYouWillBeFired: InternalAutoComplete } = AutoComplete;
const App = () => {
  const [open, setOpen] = React.useState(false);
  return (
    <Space
      direction="vertical"
      style={{
        display: 'flex',
      }}
    >
      <Switch checked={open} onChange={() => setOpen(!open)} />
      <InternalAutoComplete
        defaultValue="lucy"
        style={{
          width: 120,
        }}
        open={open}
        options={[
          {
            label: 'Jack',
            value: 'jack',
          },
          {
            label: 'Lucy',
            value: 'lucy',
          },
          {
            label: 'Disabled',
            value: 'disabled',
          },
          {
            label: 'Bamboo',
            value: 'bamboo',
          },
        ]}
      />
    </Space>
  );
};
export default App;
`,description:"<p>Debug usage. Do not use in your production.</p>"}}]}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"api",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#api",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"API"]}),(0,e.jsxs)("p",{children:[t[10].value,(0,e.jsx)(r.Z,{to:"/docs/react/common-props",sourceType:"Link",children:t[11].value})]}),(0,e.jsxs)(i.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[12].value}),(0,e.jsx)("th",{children:t[13].value}),(0,e.jsx)("th",{children:t[14].value}),(0,e.jsx)("th",{children:t[15].value}),(0,e.jsx)("th",{children:t[16].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[17].value}),(0,e.jsx)("td",{children:t[18].value}),(0,e.jsx)("td",{children:t[19].value}),(0,e.jsx)("td",{children:t[20].value}),(0,e.jsx)("td",{children:t[21].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[22].value}),(0,e.jsx)("td",{children:t[23].value}),(0,e.jsx)("td",{children:t[24].value}),(0,e.jsx)("td",{children:t[25].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[26].value}),(0,e.jsx)("td",{children:t[27].value}),(0,e.jsx)("td",{children:t[28].value}),(0,e.jsx)("td",{children:t[29].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[30].value}),(0,e.jsx)("td",{children:t[31].value}),(0,e.jsx)("td",{children:t[32].value}),(0,e.jsx)("td",{children:t[33].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[34].value}),(0,e.jsx)("td",{children:t[35].value}),(0,e.jsx)("td",{children:t[36].value}),(0,e.jsx)("td",{children:t[37].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[38].value}),(0,e.jsx)("td",{children:t[39].value}),(0,e.jsx)("td",{children:t[40].value}),(0,e.jsx)("td",{children:t[41].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[42].value}),(0,e.jsx)("td",{children:t[43].value}),(0,e.jsx)("td",{children:t[44].value}),(0,e.jsx)("td",{children:t[45].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[46].value}),(0,e.jsx)("td",{children:t[47].value}),(0,e.jsx)("td",{children:t[48].value}),(0,e.jsx)("td",{children:t[49].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[50].value}),(0,e.jsx)("td",{children:t[51].value}),(0,e.jsx)("td",{children:t[52].value}),(0,e.jsx)("td",{children:t[53].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[54].value}),(0,e.jsx)("td",{children:t[55].value}),(0,e.jsx)("td",{children:t[56].value}),(0,e.jsx)("td",{children:t[57].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[58].value}),(0,e.jsx)("td",{children:t[59].value}),(0,e.jsx)("td",{children:t[60].value}),(0,e.jsx)("td",{children:t[61].value}),(0,e.jsx)("td",{children:t[62].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[63].value}),(0,e.jsxs)("td",{children:[t[64].value,(0,e.jsx)("code",{children:t[65].value}),t[66].value,(0,e.jsx)("code",{children:t[67].value}),t[68].value]}),(0,e.jsx)("td",{children:t[69].value}),(0,e.jsx)("td",{children:t[70].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[71].value}),(0,e.jsxs)("td",{children:[t[72].value,(0,e.jsx)("code",{children:t[73].value}),t[74].value,(0,e.jsx)("code",{children:t[75].value}),t[76].value]}),(0,e.jsx)("td",{children:t[77].value}),(0,e.jsx)("td",{children:t[78].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[79].value}),(0,e.jsx)("td",{children:t[80].value}),(0,e.jsx)("td",{children:t[81].value}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[82].value})}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[83].value}),(0,e.jsx)("td",{children:t[84].value}),(0,e.jsx)("td",{children:t[85].value}),(0,e.jsx)("td",{children:t[86].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[87].value}),(0,e.jsx)("td",{children:t[88].value}),(0,e.jsx)("td",{children:t[89].value}),(0,e.jsx)("td",{children:t[90].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[91].value}),(0,e.jsx)("td",{children:t[92].value}),(0,e.jsx)("td",{children:t[93].value}),(0,e.jsx)("td",{children:t[94].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[95].value}),(0,e.jsx)("td",{children:t[96].value}),(0,e.jsx)("td",{children:t[97].value}),(0,e.jsx)("td",{children:t[98].value}),(0,e.jsx)("td",{children:t[99].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[100].value}),(0,e.jsx)("td",{children:t[101].value}),(0,e.jsx)("td",{children:t[102].value}),(0,e.jsx)("td",{children:t[103].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[104].value}),(0,e.jsx)("td",{children:t[105].value}),(0,e.jsx)("td",{children:t[106].value}),(0,e.jsx)("td",{children:t[107].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[108].value}),(0,e.jsx)("td",{children:t[109].value}),(0,e.jsx)("td",{children:t[110].value}),(0,e.jsx)("td",{children:t[111].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[112].value}),(0,e.jsx)("td",{children:t[113].value}),(0,e.jsx)("td",{children:t[114].value}),(0,e.jsx)("td",{children:t[115].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[116].value}),(0,e.jsx)("td",{children:t[117].value}),(0,e.jsx)("td",{children:t[118].value}),(0,e.jsx)("td",{children:t[119].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[120].value}),(0,e.jsx)("td",{children:t[121].value}),(0,e.jsx)("td",{children:t[122].value}),(0,e.jsx)("td",{children:t[123].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[124].value}),(0,e.jsx)("td",{children:t[125].value}),(0,e.jsx)("td",{children:t[126].value}),(0,e.jsx)("td",{children:t[127].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[128].value}),(0,e.jsx)("td",{children:t[129].value}),(0,e.jsx)("td",{children:t[130].value}),(0,e.jsx)("td",{children:t[131].value}),(0,e.jsx)("td",{children:t[132].value})]})]})]}),(0,e.jsxs)("h2",{id:"methods",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#methods",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Methods"]}),(0,e.jsxs)(i.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[133].value}),(0,e.jsx)("th",{children:t[134].value}),(0,e.jsx)("th",{children:t[135].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[136].value}),(0,e.jsx)("td",{children:t[137].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[138].value}),(0,e.jsx)("td",{children:t[139].value}),(0,e.jsx)("td",{})]})]})]}),(0,e.jsxs)("h2",{id:"design-token",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#design-token",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Design Token"]})]}),(0,e.jsx)(a.Z,{component:"Select"}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"faq",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#faq",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"FAQ"]}),(0,e.jsxs)("h3",{id:"why-doesnt-the-text-composition-system-work-well-with-onsearch-in-controlled-mode",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#why-doesnt-the-text-composition-system-work-well-with-onsearch-in-controlled-mode",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Why doesn't the text composition system work well with onSearch in controlled mode?"]}),(0,e.jsxs)("p",{children:[t[140].value,(0,e.jsx)("code",{children:t[141].value}),t[142].value,(0,e.jsx)("code",{children:t[143].value}),t[144].value,(0,e.jsx)("code",{children:t[145].value}),t[146].value,(0,e.jsx)("code",{children:t[147].value}),t[148].value]}),(0,e.jsxs)("p",{children:[t[149].value,(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/issues/18230",sourceType:"a",children:t[150].value}),t[151].value,(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/issues/17916",sourceType:"a",children:t[152].value})]}),(0,e.jsxs)("h3",{id:"why-wont-a-controlled-open-autocomplete-display-a-drop-down-menu-when-options-are-empty",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#why-wont-a-controlled-open-autocomplete-display-a-drop-down-menu-when-options-are-empty",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Why won't a controlled open AutoComplete display a drop-down menu when options are empty?"]}),(0,e.jsxs)("p",{children:[t[153].value,(0,e.jsx)("code",{children:t[154].value}),t[155].value,(0,e.jsx)("code",{children:t[156].value}),t[157].value,(0,e.jsx)("code",{children:t[158].value}),t[159].value,(0,e.jsx)("code",{children:t[160].value}),t[161].value,(0,e.jsx)("code",{children:t[162].value}),t[163].value,(0,e.jsx)("code",{children:t[164].value}),t[165].value]})]})]})})}s.default=l}}]);
