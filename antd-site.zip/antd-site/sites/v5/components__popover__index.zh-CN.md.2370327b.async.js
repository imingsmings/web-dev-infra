"use strict";(self.webpackChunkantd=self.webpackChunkantd||[]).push([[72990],{651877:function(d,o,n){n.r(o);var m=n(863942),u=n(502143),g=n(968521),y=n(702951),h=n(521587),v=n(199100),s=n(828089),b=n(825673),j=n(902068),_=n(574399),k=n(316073),f=n(24628),x=n(719260),P=n(956140),c=n(127179),a=n(905388),w=n(245583),C=n(606965),B=n(268696),E=n(587302),r=n(424128),D=n(249706),T=n(795127),O=n(116846),A=n(720538),z=n(212039),M=n(73024),I=n(553913),i=n(385956),U=n(667294),e=n(785893);function p(){var l=(0,i.useRouteMeta)(),t=l.texts;return(0,e.jsx)(i.DumiPage,{children:(0,e.jsxs)(e.Fragment,{children:[(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsx)("p",{children:t[0].value}),(0,e.jsxs)("h2",{id:"\u4F55\u65F6\u4F7F\u7528",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4F55\u65F6\u4F7F\u7528",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4F55\u65F6\u4F7F\u7528"]}),(0,e.jsx)("p",{children:t[1].value}),(0,e.jsxs)("p",{children:[t[2].value,(0,e.jsx)("code",{children:t[3].value}),t[4].value]}),(0,e.jsxs)("h2",{id:"\u4EE3\u7801\u6F14\u793A",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4EE3\u7801\u6F14\u793A",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4EE3\u7801\u6F14\u793A"]})]}),(0,e.jsx)(a.Z,{items:[{demo:{id:"popover-demo-basic"},previewerProps:{title:"\u57FA\u672C",filename:"components/popover/demo/basic.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Button, Popover } from 'antd';
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const App = () => (
  <Popover content={content} title="Title">
    <Button type="primary">Hover me</Button>
  </Popover>
);
export default App;
`,description:"<p>\u6700\u7B80\u5355\u7684\u7528\u6CD5\uFF0C\u6D6E\u5C42\u7684\u5927\u5C0F\u7531\u5185\u5BB9\u533A\u57DF\u51B3\u5B9A\u3002</p>",style:`.ant-popover-content p {
  margin: 0;
}`}},{demo:{id:"popover-demo-triggertype"},previewerProps:{title:"\u4E09\u79CD\u89E6\u53D1\u65B9\u5F0F",filename:"components/popover/demo/triggerType.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Button, Popover, Space } from 'antd';
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const App = () => (
  <Space wrap>
    <Popover content={content} title="Title" trigger="hover">
      <Button>Hover me</Button>
    </Popover>
    <Popover content={content} title="Title" trigger="focus">
      <Button>Focus me</Button>
    </Popover>
    <Popover content={content} title="Title" trigger="click">
      <Button>Click me</Button>
    </Popover>
  </Space>
);
export default App;
`,description:"<p>\u9F20\u6807\u79FB\u5165\u3001\u805A\u96C6\u3001\u70B9\u51FB\u3002</p>"}},{demo:{id:"popover-demo-placement"},previewerProps:{title:"\u4F4D\u7F6E",filename:"components/popover/demo/placement.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Button, Popover, ConfigProvider } from 'antd';
const text = <span>Title</span>;
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const buttonWidth = 80;
const App = () => (
  <ConfigProvider
    button={{
      style: {
        width: buttonWidth,
        margin: 4,
      },
    }}
  >
    <div className="demo">
      <div
        style={{
          marginInlineStart: buttonWidth + 4,
          whiteSpace: 'nowrap',
        }}
      >
        <Popover placement="topLeft" title={text} content={content}>
          <Button>TL</Button>
        </Popover>
        <Popover placement="top" title={text} content={content}>
          <Button>Top</Button>
        </Popover>
        <Popover placement="topRight" title={text} content={content}>
          <Button>TR</Button>
        </Popover>
      </div>
      <div
        style={{
          width: buttonWidth,
          float: 'inline-start',
        }}
      >
        <Popover placement="leftTop" title={text} content={content}>
          <Button>LT</Button>
        </Popover>
        <Popover placement="left" title={text} content={content}>
          <Button>Left</Button>
        </Popover>
        <Popover placement="leftBottom" title={text} content={content}>
          <Button>LB</Button>
        </Popover>
      </div>
      <div
        style={{
          width: buttonWidth,
          marginInlineStart: buttonWidth * 4 + 24,
        }}
      >
        <Popover placement="rightTop" title={text} content={content}>
          <Button>RT</Button>
        </Popover>
        <Popover placement="right" title={text} content={content}>
          <Button>Right</Button>
        </Popover>
        <Popover placement="rightBottom" title={text} content={content}>
          <Button>RB</Button>
        </Popover>
      </div>
      <div
        style={{
          marginInlineStart: buttonWidth,
          clear: 'both',
          whiteSpace: 'nowrap',
        }}
      >
        <Popover placement="bottomLeft" title={text} content={content}>
          <Button>BL</Button>
        </Popover>
        <Popover placement="bottom" title={text} content={content}>
          <Button>Bottom</Button>
        </Popover>
        <Popover placement="bottomRight" title={text} content={content}>
          <Button>BR</Button>
        </Popover>
      </div>
    </div>
  </ConfigProvider>
);
export default App;
`,description:"<p>\u4F4D\u7F6E\u6709\u5341\u4E8C\u4E2A\u65B9\u5411\u3002</p>"}},{demo:{id:"popover-demo-arrow"},previewerProps:{title:"\u7BAD\u5934\u5C55\u793A",filename:"components/popover/demo/arrow.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useMemo, useState } from 'react';
import { Button, ConfigProvider, Popover, Segmented } from 'antd';
const text = <span>Title</span>;
const buttonWidth = 80;
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const App = () => {
  const [arrow, setArrow] = useState('Show');
  const mergedArrow = useMemo(() => {
    if (arrow === 'Hide') {
      return false;
    }
    if (arrow === 'Show') {
      return true;
    }
    return {
      pointAtCenter: true,
    };
  }, [arrow]);
  return (
    <ConfigProvider
      button={{
        style: {
          width: buttonWidth,
          margin: 4,
        },
      }}
    >
      <Segmented
        options={['Show', 'Hide', 'Center']}
        onChange={(val) => setArrow(val)}
        style={{
          marginBottom: 24,
        }}
      />
      <div className="demo">
        <div
          style={{
            marginInlineStart: buttonWidth + 4,
            whiteSpace: 'nowrap',
          }}
        >
          <Popover placement="topLeft" title={text} content={content} arrow={mergedArrow}>
            <Button>TL</Button>
          </Popover>
          <Popover placement="top" title={text} content={content} arrow={mergedArrow}>
            <Button>Top</Button>
          </Popover>
          <Popover placement="topRight" title={text} content={content} arrow={mergedArrow}>
            <Button>TR</Button>
          </Popover>
        </div>
        <div
          style={{
            width: buttonWidth,
            float: 'inline-start',
          }}
        >
          <Popover placement="leftTop" title={text} content={content} arrow={mergedArrow}>
            <Button>LT</Button>
          </Popover>
          <Popover placement="left" title={text} content={content} arrow={mergedArrow}>
            <Button>Left</Button>
          </Popover>
          <Popover placement="leftBottom" title={text} content={content} arrow={mergedArrow}>
            <Button>LB</Button>
          </Popover>
        </div>
        <div
          style={{
            width: buttonWidth,
            marginInlineStart: buttonWidth * 4 + 24,
          }}
        >
          <Popover placement="rightTop" title={text} content={content} arrow={mergedArrow}>
            <Button>RT</Button>
          </Popover>
          <Popover placement="right" title={text} content={content} arrow={mergedArrow}>
            <Button>Right</Button>
          </Popover>
          <Popover placement="rightBottom" title={text} content={content} arrow={mergedArrow}>
            <Button>RB</Button>
          </Popover>
        </div>
        <div
          style={{
            marginInlineStart: buttonWidth,
            clear: 'both',
            whiteSpace: 'nowrap',
          }}
        >
          <Popover placement="bottomLeft" title={text} content={content} arrow={mergedArrow}>
            <Button>BL</Button>
          </Popover>
          <Popover placement="bottom" title={text} content={content} arrow={mergedArrow}>
            <Button>Bottom</Button>
          </Popover>
          <Popover placement="bottomRight" title={text} content={content} arrow={mergedArrow}>
            <Button>BR</Button>
          </Popover>
        </div>
      </div>
    </ConfigProvider>
  );
};
export default App;
`,description:"<p>\u901A\u8FC7 <code>arrow</code> \u5C5E\u6027\u9690\u85CF\u7BAD\u5934\u3002</p>"}},{demo:{id:"popover-demo-control"},previewerProps:{title:"\u4ECE\u6D6E\u5C42\u5185\u5173\u95ED",filename:"components/popover/demo/control.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { Button, Popover } from 'antd';
const App = () => {
  const [open, setOpen] = useState(false);
  const hide = () => {
    setOpen(false);
  };
  const handleOpenChange = (newOpen) => {
    setOpen(newOpen);
  };
  return (
    <Popover
      content={<a onClick={hide}>Close</a>}
      title="Title"
      trigger="click"
      open={open}
      onOpenChange={handleOpenChange}
    >
      <Button type="primary">Click me</Button>
    </Popover>
  );
};
export default App;
`,description:"<p>\u4F7F\u7528 <code>open</code> \u5C5E\u6027\u63A7\u5236\u6D6E\u5C42\u663E\u793A\u3002</p>"}},{demo:{id:"popover-demo-hover-with-click"},previewerProps:{title:"\u60AC\u505C\u70B9\u51FB\u5F39\u51FA\u7A97\u53E3",filename:"components/popover/demo/hover-with-click.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { Button, Popover } from 'antd';
const App = () => {
  const [clicked, setClicked] = useState(false);
  const [hovered, setHovered] = useState(false);
  const hide = () => {
    setClicked(false);
    setHovered(false);
  };
  const handleHoverChange = (open) => {
    setHovered(open);
    setClicked(false);
  };
  const handleClickChange = (open) => {
    setHovered(false);
    setClicked(open);
  };
  const hoverContent = <div>This is hover content.</div>;
  const clickContent = <div>This is click content.</div>;
  return (
    <Popover
      style={{
        width: 500,
      }}
      content={hoverContent}
      title="Hover title"
      trigger="hover"
      open={hovered}
      onOpenChange={handleHoverChange}
    >
      <Popover
        content={
          <div>
            {clickContent}
            <a onClick={hide}>Close</a>
          </div>
        }
        title="Click title"
        trigger="click"
        open={clicked}
        onOpenChange={handleClickChange}
      >
        <Button>Hover and click / \u60AC\u505C\u5E76\u5355\u51FB</Button>
      </Popover>
    </Popover>
  );
};
export default App;
`,description:"<p>\u4EE5\u4E0B\u793A\u4F8B\u663E\u793A\u5982\u4F55\u521B\u5EFA\u53EF\u60AC\u505C\u548C\u5355\u51FB\u7684\u5F39\u51FA\u7A97\u53E3\u3002</p>"}},{demo:{id:"popover-demo-render-panel"},previewerProps:{debug:!0,title:"_InternalPanelDoNotUseOrYouWillBeFired",filename:"components/popover/demo/render-panel.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Popover } from 'antd';
const { _InternalPanelDoNotUseOrYouWillBeFired: InternalPopover } = Popover;
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const App = () => (
  <>
    <InternalPopover content={content} title="Title" />
    <InternalPopover
      content={content}
      title="Title"
      placement="bottomLeft"
      style={{
        width: 250,
      }}
    />
  </>
);
export default App;
`,description:"<p>\u8C03\u8BD5\u7528\u7EC4\u4EF6\uFF0C\u8BF7\u52FF\u76F4\u63A5\u4F7F\u7528\u3002</p>"}},{demo:{id:"popover-demo-wireframe"},previewerProps:{debug:!0,title:"\u7EBF\u6846\u98CE\u683C",filename:"components/popover/demo/wireframe.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { ConfigProvider, Popover } from 'antd';
const { _InternalPanelDoNotUseOrYouWillBeFired: InternalPopover } = Popover;
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const App = () => (
  <ConfigProvider
    theme={{
      token: {
        wireframe: true,
      },
    }}
  >
    <InternalPopover content={content} title="Title" />
    <InternalPopover
      content={content}
      title="Title"
      placement="bottomLeft"
      style={{
        width: 250,
      }}
    />
  </ConfigProvider>
);
export default App;
`,description:"<p>\u7EBF\u6846\u6837\u5F0F\u3002</p>"}},{demo:{id:"popover-demo-component-token"},previewerProps:{debug:!0,title:"\u7EC4\u4EF6 Token",filename:"components/popover/demo/component-token.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { ConfigProvider, Popover } from 'antd';
const { _InternalPanelDoNotUseOrYouWillBeFired: InternalPopover } = Popover;
const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
);
const App = () => (
  <ConfigProvider
    theme={{
      components: {
        Popover: {
          titleMinWidth: 40,
        },
      },
    }}
  >
    <InternalPopover content={content} title="Title" />
    <InternalPopover
      content={content}
      title="Title"
      placement="bottomLeft"
      style={{
        width: 250,
      }}
    />
  </ConfigProvider>
);
export default App;
`,description:"<p>Component Token Debug.</p>"}}]}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"api",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#api",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"API"]}),(0,e.jsxs)("p",{children:[t[5].value,(0,e.jsx)(r.Z,{to:"/docs/react/common-props",sourceType:"Link",children:t[6].value})]}),(0,e.jsxs)(s.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[7].value}),(0,e.jsx)("th",{children:t[8].value}),(0,e.jsx)("th",{children:t[9].value}),(0,e.jsx)("th",{children:t[10].value}),(0,e.jsx)("th",{children:t[11].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[12].value}),(0,e.jsx)("td",{children:t[13].value}),(0,e.jsx)("td",{children:t[14].value}),(0,e.jsx)("td",{children:t[15].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[16].value}),(0,e.jsx)("td",{children:t[17].value}),(0,e.jsx)("td",{children:t[18].value}),(0,e.jsx)("td",{children:t[19].value}),(0,e.jsx)("td",{})]})]})]}),(0,e.jsxs)("p",{children:[t[20].value,(0,e.jsx)(r.Z,{to:"/components/tooltip-cn/#api",sourceType:"Link",children:t[21].value}),t[22].value]}),(0,e.jsxs)("h2",{id:"\u6CE8\u610F",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u6CE8\u610F",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u6CE8\u610F"]}),(0,e.jsxs)("p",{children:[t[23].value,(0,e.jsx)("code",{children:t[24].value}),t[25].value,(0,e.jsx)("code",{children:t[26].value}),t[27].value,(0,e.jsx)("code",{children:t[28].value}),t[29].value,(0,e.jsx)("code",{children:t[30].value}),t[31].value,(0,e.jsx)("code",{children:t[32].value}),t[33].value]}),(0,e.jsxs)("h2",{id:"\u4E3B\u9898\u53D8\u91CFdesign-token",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4E3B\u9898\u53D8\u91CFdesign-token",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4E3B\u9898\u53D8\u91CF\uFF08Design Token\uFF09"]})]}),(0,e.jsx)(c.Z,{component:"Popover"}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"faq",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#faq",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"FAQ"]}),(0,e.jsxs)("p",{children:[t[34].value,(0,e.jsx)(r.Z,{to:"/components/tooltip#faq",sourceType:"Link",children:t[35].value}),t[36].value]})]})]})})}o.default=p}}]);
