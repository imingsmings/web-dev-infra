"use strict";(self.webpackChunkantd=self.webpackChunkantd||[]).push([[5610],{332457:function(u,i,n){n.r(i);var m=n(863942),g=n(502143),y=n(968521),h=n(702951),j=n(521587),s=n(199100),o=n(828089),f=n(825673),b=n(902068),v=n(574399),x=n(316073),k=n(24628),w=n(719260),_=n(956140),l=n(127179),c=n(905388),U=n(245583),E=n(606965),z=n(268696),P=n(587302),r=n(424128),L=n(249706),D=n(795127),q=n(116846),O=n(720538),C=n(212039),F=n(73024),B=n(553913),a=n(385956),T=n(667294),e=n(785893);function p(){var d=(0,a.useRouteMeta)(),t=d.texts;return(0,e.jsx)(a.DumiPage,{children:(0,e.jsxs)(e.Fragment,{children:[(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsx)("p",{children:t[0].value}),(0,e.jsxs)("h2",{id:"\u4F55\u65F6\u4F7F\u7528",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4F55\u65F6\u4F7F\u7528",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4F55\u65F6\u4F7F\u7528"]}),(0,e.jsx)("p",{children:t[1].value}),(0,e.jsxs)("ul",{children:[(0,e.jsx)("li",{children:t[2].value}),(0,e.jsx)("li",{children:t[3].value}),(0,e.jsx)("li",{children:t[4].value})]}),(0,e.jsxs)("h2",{id:"\u4EE3\u7801\u6F14\u793A",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4EE3\u7801\u6F14\u793A",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4EE3\u7801\u6F14\u793A"]})]}),(0,e.jsx)(c.Z,{items:[{demo:{id:"components-upload-demo-basic"},previewerProps:{title:"\u70B9\u51FB\u4E0A\u4F20",filename:"components/upload/demo/basic.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, message, Upload } from 'antd';
const props = {
  name: 'file',
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  headers: {
    authorization: 'authorization-text',
  },
  onChange(info) {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      message.success(\`\${info.file.name} file uploaded successfully\`);
    } else if (info.file.status === 'error') {
      message.error(\`\${info.file.name} file upload failed.\`);
    }
  },
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Click to Upload</Button>
  </Upload>
);
export default App;
`,description:"<p>\u7ECF\u5178\u6B3E\u5F0F\uFF0C\u7528\u6237\u70B9\u51FB\u6309\u94AE\u5F39\u51FA\u6587\u4EF6\u9009\u62E9\u6846\u3002</p>"}},{demo:{id:"components-upload-demo-avatar"},previewerProps:{title:"\u7528\u6237\u5934\u50CF",filename:"components/upload/demo/avatar.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import { message, Upload } from 'antd';
const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
};
const beforeUpload = (file) => {
  const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
  if (!isJpgOrPng) {
    message.error('You can only upload JPG/PNG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJpgOrPng && isLt2M;
};
const App = () => {
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState();
  const handleChange = (info) => {
    if (info.file.status === 'uploading') {
      setLoading(true);
      return;
    }
    if (info.file.status === 'done') {
      // Get this url from response in real world.
      getBase64(info.file.originFileObj, (url) => {
        setLoading(false);
        setImageUrl(url);
      });
    }
  };
  const uploadButton = (
    <div>
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  return (
    <>
      <Upload
        name="avatar"
        listType="picture-card"
        className="avatar-uploader"
        showUploadList={false}
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        beforeUpload={beforeUpload}
        onChange={handleChange}
      >
        {imageUrl ? (
          <img
            src={imageUrl}
            alt="avatar"
            style={{
              width: '100%',
            }}
          />
        ) : (
          uploadButton
        )}
      </Upload>
      <Upload
        name="avatar"
        listType="picture-circle"
        className="avatar-uploader"
        showUploadList={false}
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        beforeUpload={beforeUpload}
        onChange={handleChange}
      >
        {imageUrl ? (
          <img
            src={imageUrl}
            alt="avatar"
            style={{
              width: '100%',
            }}
          />
        ) : (
          uploadButton
        )}
      </Upload>
    </>
  );
};
export default App;
`,description:`<p>\u70B9\u51FB\u4E0A\u4F20\u7528\u6237\u5934\u50CF\uFF0C\u5E76\u4F7F\u7528 <code>beforeUpload</code> \u9650\u5236\u7528\u6237\u4E0A\u4F20\u7684\u56FE\u7247\u683C\u5F0F\u548C\u5927\u5C0F\u3002</p>
<blockquote>
<p><code>beforeUpload</code> \u7684\u8FD4\u56DE\u503C\u53EF\u4EE5\u662F\u4E00\u4E2A Promise \u4EE5\u652F\u6301\u5F02\u6B65\u5904\u7406\uFF0C\u5982\u670D\u52A1\u7AEF\u6821\u9A8C\u7B49\uFF1A<a href="https://upload-react-component.vercel.app/demo/before-upload#beforeupload">\u793A\u4F8B</a>\u3002</p>
</blockquote>`}},{demo:{id:"components-upload-demo-defaultfilelist"},previewerProps:{title:"\u5DF2\u4E0A\u4F20\u7684\u6587\u4EF6\u5217\u8868",filename:"components/upload/demo/defaultFileList.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const props = {
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  onChange({ file, fileList }) {
    if (file.status !== 'uploading') {
      console.log(file, fileList);
    }
  },
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    {
      uid: '2',
      name: 'yyy.png',
      status: 'done',
      url: 'http://www.baidu.com/yyy.png',
    },
    {
      uid: '3',
      name: 'zzz.png',
      status: 'error',
      response: 'Server Error 500',
      // custom error message to show
      url: 'http://www.baidu.com/zzz.png',
    },
  ],
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Upload</Button>
  </Upload>
);
export default App;
`,description:"<p>\u4F7F\u7528 <code>defaultFileList</code> \u8BBE\u7F6E\u5DF2\u4E0A\u4F20\u7684\u5185\u5BB9\u3002</p>"}},{demo:{id:"components-upload-demo-picture-card"},previewerProps:{title:"\u7167\u7247\u5899",filename:"components/upload/demo/picture-card.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import { Modal, Upload } from 'antd';
const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
const App = () => {
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [previewTitle, setPreviewTitle] = useState('');
  const [fileList, setFileList] = useState([
    {
      uid: '-1',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-2',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-3',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-4',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-xxx',
      percent: 50,
      name: 'image.png',
      status: 'uploading',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-5',
      name: 'image.png',
      status: 'error',
    },
  ]);
  const handleCancel = () => setPreviewOpen(false);
  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
    setPreviewTitle(file.name || file.url.substring(file.url.lastIndexOf('/') + 1));
  };
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  return (
    <>
      <Upload
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        listType="picture-card"
        fileList={fileList}
        onPreview={handlePreview}
        onChange={handleChange}
      >
        {fileList.length >= 8 ? null : uploadButton}
      </Upload>
      <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
        <img
          alt="example"
          style={{
            width: '100%',
          }}
          src={previewImage}
        />
      </Modal>
    </>
  );
};
export default App;
`,description:"<p>\u7528\u6237\u53EF\u4EE5\u4E0A\u4F20\u56FE\u7247\u5E76\u5728\u5217\u8868\u4E2D\u663E\u793A\u7F29\u7565\u56FE\u3002\u5F53\u4E0A\u4F20\u7167\u7247\u6570\u5230\u8FBE\u9650\u5236\u540E\uFF0C\u4E0A\u4F20\u6309\u94AE\u6D88\u5931\u3002</p>"}},{demo:{id:"components-upload-demo-picture-circle"},previewerProps:{title:"\u5706\u5F62\u7167\u7247\u5899",filename:"components/upload/demo/picture-circle.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import { Modal, Upload } from 'antd';
const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
const App = () => {
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [previewTitle, setPreviewTitle] = useState('');
  const [fileList, setFileList] = useState([
    {
      uid: '-1',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-xxx',
      percent: 50,
      name: 'image.png',
      status: 'uploading',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-5',
      name: 'image.png',
      status: 'error',
    },
  ]);
  const handleCancel = () => setPreviewOpen(false);
  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
    setPreviewTitle(file.name || file.url.substring(file.url.lastIndexOf('/') + 1));
  };
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  return (
    <>
      <Upload
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        listType="picture-circle"
        fileList={fileList}
        onPreview={handlePreview}
        onChange={handleChange}
      >
        {fileList.length >= 8 ? null : uploadButton}
      </Upload>
      <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
        <img
          alt="example"
          style={{
            width: '100%',
          }}
          src={previewImage}
        />
      </Modal>
    </>
  );
};
export default App;
`,description:"<p>\u56FE\u7247\u5361\u7684\u66FF\u4EE3\u663E\u793A\u3002</p>"}},{demo:{id:"components-upload-demo-filelist"},previewerProps:{title:"\u5B8C\u5168\u63A7\u5236\u7684\u4E0A\u4F20\u5217\u8868",filename:"components/upload/demo/fileList.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const App = () => {
  const [fileList, setFileList] = useState([
    {
      uid: '-1',
      name: 'xxx.png',
      status: 'done',
      url: 'http://www.baidu.com/xxx.png',
    },
  ]);
  const handleChange = (info) => {
    let newFileList = [...info.fileList];

    // 1. Limit the number of uploaded files
    // Only to show two recent uploaded files, and old ones will be replaced by the new
    newFileList = newFileList.slice(-2);

    // 2. Read from response and show file link
    newFileList = newFileList.map((file) => {
      if (file.response) {
        // Component will show file.url as link
        file.url = file.response.url;
      }
      return file;
    });
    setFileList(newFileList);
  };
  const props = {
    action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
    onChange: handleChange,
    multiple: true,
  };
  return (
    <Upload {...props} fileList={fileList}>
      <Button icon={<UploadOutlined />}>Upload</Button>
    </Upload>
  );
};
export default App;
`,description:`<p>\u4F7F\u7528 <code>fileList</code> \u5BF9\u5217\u8868\u8FDB\u884C\u5B8C\u5168\u63A7\u5236\uFF0C\u53EF\u4EE5\u5B9E\u73B0\u5404\u79CD\u81EA\u5B9A\u4E49\u529F\u80FD\uFF0C\u4EE5\u4E0B\u6F14\u793A\u4E8C\u79CD\u60C5\u51B5\uFF1A</p>
<ol>
<li>
<p>\u4E0A\u4F20\u5217\u8868\u6570\u91CF\u7684\u9650\u5236\u3002</p>
</li>
<li>
<p>\u8BFB\u53D6\u8FDC\u7A0B\u8DEF\u5F84\u5E76\u663E\u793A\u94FE\u63A5\u3002</p>
</li>
</ol>`}},{demo:{id:"components-upload-demo-drag"},previewerProps:{title:"\u62D6\u62FD\u4E0A\u4F20",filename:"components/upload/demo/drag.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { InboxOutlined } from '@ant-design/icons';
import { message, Upload } from 'antd';
const { Dragger } = Upload;
const props = {
  name: 'file',
  multiple: true,
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      message.success(\`\${info.file.name} file uploaded successfully.\`);
    } else if (status === 'error') {
      message.error(\`\${info.file.name} file upload failed.\`);
    }
  },
  onDrop(e) {
    console.log('Dropped files', e.dataTransfer.files);
  },
};
const App = () => (
  <Dragger {...props}>
    <p className="ant-upload-drag-icon">
      <InboxOutlined />
    </p>
    <p className="ant-upload-text">Click or drag file to this area to upload</p>
    <p className="ant-upload-hint">
      Support for a single or bulk upload. Strictly prohibited from uploading company data or other
      banned files.
    </p>
  </Dragger>
);
export default App;
`,description:`<p>\u628A\u6587\u4EF6\u62D6\u5165\u6307\u5B9A\u533A\u57DF\uFF0C\u5B8C\u6210\u4E0A\u4F20\uFF0C\u540C\u6837\u652F\u6301\u70B9\u51FB\u4E0A\u4F20\u3002</p>
<p>\u8BBE\u7F6E <code>multiple</code> \u540E\uFF0C\u5728 <code>IE10+</code> \u53EF\u4EE5\u4E00\u6B21\u4E0A\u4F20\u591A\u4E2A\u6587\u4EF6\u3002</p>`}},{demo:{id:"components-upload-demo-directory"},previewerProps:{title:"\u6587\u4EF6\u5939\u4E0A\u4F20",filename:"components/upload/demo/directory.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const App = () => (
  <Upload action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188" directory>
    <Button icon={<UploadOutlined />}>Upload Directory</Button>
  </Upload>
);
export default App;
`,description:'<p>\u652F\u6301\u4E0A\u4F20\u4E00\u4E2A\u6587\u4EF6\u5939\u91CC\u7684\u6240\u6709\u6587\u4EF6\u3002 <a href="&#x27;#/%E6%96%87%E4%BB%B6%E5%A4%B9%E4%B8%8A%E4%BC%A0%E5%9C%A8%20Safari%20%E4%BB%8D%E7%84%B6%E5%8F%AF%E4%BB%A5%E9%80%89%E4%B8%AD%E6%96%87%E4%BB%B6&#x27;">Safari \u91CC\u4ECD\u7136\u80FD\u9009\u62E9\u6587\u4EF6?</a></p>'}},{demo:{id:"components-upload-demo-upload-manually"},previewerProps:{title:"\u624B\u52A8\u4E0A\u4F20",filename:"components/upload/demo/upload-manually.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, message, Upload } from 'antd';
const App = () => {
  const [fileList, setFileList] = useState([]);
  const [uploading, setUploading] = useState(false);
  const handleUpload = () => {
    const formData = new FormData();
    fileList.forEach((file) => {
      formData.append('files[]', file);
    });
    setUploading(true);
    // You can use any AJAX library you like
    fetch('https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188', {
      method: 'POST',
      body: formData,
    })
      .then((res) => res.json())
      .then(() => {
        setFileList([]);
        message.success('upload successfully.');
      })
      .catch(() => {
        message.error('upload failed.');
      })
      .finally(() => {
        setUploading(false);
      });
  };
  const props = {
    onRemove: (file) => {
      const index = fileList.indexOf(file);
      const newFileList = fileList.slice();
      newFileList.splice(index, 1);
      setFileList(newFileList);
    },
    beforeUpload: (file) => {
      setFileList([...fileList, file]);
      return false;
    },
    fileList,
  };
  return (
    <>
      <Upload {...props}>
        <Button icon={<UploadOutlined />}>Select File</Button>
      </Upload>
      <Button
        type="primary"
        onClick={handleUpload}
        disabled={fileList.length === 0}
        loading={uploading}
        style={{
          marginTop: 16,
        }}
      >
        {uploading ? 'Uploading' : 'Start Upload'}
      </Button>
    </>
  );
};
export default App;
`,description:"<p><code>beforeUpload</code> \u8FD4\u56DE <code>false</code> \u540E\uFF0C\u624B\u52A8\u4E0A\u4F20\u6587\u4EF6\u3002</p>"}},{demo:{id:"components-upload-demo-upload-png-only"},previewerProps:{title:"\u53EA\u4E0A\u4F20 png \u56FE\u7247",filename:"components/upload/demo/upload-png-only.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, message, Upload } from 'antd';
const props = {
  beforeUpload: (file) => {
    const isPNG = file.type === 'image/png';
    if (!isPNG) {
      message.error(\`\${file.name} is not a png file\`);
    }
    return isPNG || Upload.LIST_IGNORE;
  },
  onChange: (info) => {
    console.log(info.fileList);
  },
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Upload png only</Button>
  </Upload>
);
export default App;
`,description:'<p><code>beforeUpload</code> \u8FD4\u56DE <code>false</code> \u6216 <code>Promise.reject</code> \u65F6\uFF0C\u53EA\u7528\u4E8E\u62E6\u622A\u4E0A\u4F20\u884C\u4E3A\uFF0C\u4E0D\u4F1A\u963B\u6B62\u6587\u4EF6\u8FDB\u5165\u4E0A\u4F20\u5217\u8868\uFF08<a href="https://github.com/ant-design/ant-design/issues/15561#issuecomment-475108235">\u539F\u56E0</a>\uFF09\u3002\u5982\u679C\u9700\u8981\u963B\u6B62\u5217\u8868\u5C55\u73B0\uFF0C\u53EF\u4EE5\u901A\u8FC7\u8FD4\u56DE <code>Upload.LIST_IGNORE</code> \u5B9E\u73B0\u3002</p>'}},{demo:{id:"components-upload-demo-picture-style"},previewerProps:{title:"\u56FE\u7247\u5217\u8868\u6837\u5F0F",filename:"components/upload/demo/picture-style.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const fileList = [
  {
    uid: '0',
    name: 'xxx.png',
    status: 'uploading',
    percent: 33,
  },
  {
    uid: '-1',
    name: 'yyy.png',
    status: 'done',
    url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    thumbUrl: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
  },
  {
    uid: '-2',
    name: 'zzz.png',
    status: 'error',
  },
];
const App = () => (
  <>
    <Upload
      action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
      listType="picture"
      defaultFileList={[...fileList]}
    >
      <Button icon={<UploadOutlined />}>Upload</Button>
    </Upload>
    <br />
    <br />
    <Upload
      action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
      listType="picture"
      defaultFileList={[...fileList]}
      className="upload-list-inline"
    >
      <Button icon={<UploadOutlined />}>Upload</Button>
    </Upload>
  </>
);
export default App;
`,description:'<p>\u4E0A\u4F20\u6587\u4EF6\u4E3A\u56FE\u7247\uFF0C\u53EF\u5C55\u793A\u672C\u5730\u7F29\u7565\u56FE\u3002<code>IE8/9</code> \u4E0D\u652F\u6301\u6D4F\u89C8\u5668\u672C\u5730\u7F29\u7565\u56FE\u5C55\u793A\uFF08<a href="https://developer.mozilla.org/en-US/docs/Web/API/FileReader/readAsDataURL">Ref</a>\uFF09\uFF0C\u53EF\u4EE5\u5199 <code>thumbUrl</code> \u5C5E\u6027\u6765\u4EE3\u66FF\u3002</p>',style:`/* tile uploaded pictures */
.upload-list-inline .ant-upload-list-item {
  float: left;
  width: 200px;
  margin-inline-end: 8px;
}

.ant-upload-rtl.upload-list-inline .ant-upload-list-item {
  float: right;
}`}},{demo:{id:"components-upload-demo-preview-file"},previewerProps:{title:"\u81EA\u5B9A\u4E49\u9884\u89C8",filename:"components/upload/demo/preview-file.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const props = {
  action: '//jsonplaceholder.typicode.com/posts/',
  listType: 'picture',
  previewFile(file) {
    console.log('Your upload file:', file);
    // Your process logic. Here we just mock to the same file
    return fetch('https://next.json-generator.com/api/json/get/4ytyBoLK8', {
      method: 'POST',
      body: file,
    })
      .then((res) => res.json())
      .then(({ thumbnail }) => thumbnail);
  },
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Upload</Button>
  </Upload>
);
export default App;
`,description:"<p>\u81EA\u5B9A\u4E49\u672C\u5730\u9884\u89C8\uFF0C\u7528\u4E8E\u5904\u7406\u975E\u56FE\u7247\u683C\u5F0F\u6587\u4EF6\uFF08\u4F8B\u5982\u89C6\u9891\u6587\u4EF6\uFF09\u3002</p>"}},{demo:{id:"components-upload-demo-max-count"},previewerProps:{title:"\u9650\u5236\u6570\u91CF",filename:"components/upload/demo/max-count.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Space, Upload } from 'antd';
const App = () => (
  <Space
    direction="vertical"
    style={{
      width: '100%',
    }}
    size="large"
  >
    <Upload
      action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
      listType="picture"
      maxCount={1}
    >
      <Button icon={<UploadOutlined />}>Upload (Max: 1)</Button>
    </Upload>
    <Upload
      action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
      listType="picture"
      maxCount={3}
      multiple
    >
      <Button icon={<UploadOutlined />}>Upload (Max: 3)</Button>
    </Upload>
  </Space>
);
export default App;
`,description:"<p>\u901A\u8FC7 <code>maxCount</code> \u9650\u5236\u4E0A\u4F20\u6570\u91CF\u3002\u5F53\u4E3A <code>1</code> \u65F6\uFF0C\u59CB\u7EC8\u7528\u6700\u65B0\u4E0A\u4F20\u7684\u4EE3\u66FF\u5F53\u524D\u3002</p>"}},{demo:{id:"components-upload-demo-transform-file"},previewerProps:{title:"\u4E0A\u4F20\u524D\u8F6C\u6362\u6587\u4EF6",filename:"components/upload/demo/transform-file.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const props = {
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  listType: 'picture',
  beforeUpload(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const img = document.createElement('img');
        img.src = reader.result;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0);
          ctx.fillStyle = 'red';
          ctx.textBaseline = 'middle';
          ctx.font = '33px Arial';
          ctx.fillText('Ant Design', 20, 20);
          canvas.toBlob((result) => resolve(result));
        };
      };
    });
  },
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Upload</Button>
  </Upload>
);
export default App;
`,description:"<p>\u4F7F\u7528 <code>beforeUpload</code> \u8F6C\u6362\u4E0A\u4F20\u7684\u6587\u4EF6\uFF08\u4F8B\u5982\u6DFB\u52A0\u6C34\u5370\uFF09\u3002</p>"}},{demo:{id:"components-upload-demo-upload-with-aliyun-oss"},previewerProps:{title:"\u963F\u91CC\u4E91 OSS",filename:"components/upload/demo/upload-with-aliyun-oss.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useEffect, useState } from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, Form, message, Upload } from 'antd';
const AliyunOSSUpload = ({ value, onChange }) => {
  const [OSSData, setOSSData] = useState();

  // Mock get OSS api
  // https://help.aliyun.com/document_detail/31988.html
  const mockGetOSSData = () => ({
    dir: 'user-dir/',
    expire: '1577811661',
    host: '//www.mocky.io/v2/5cc8019d300000980a055e76',
    accessId: 'c2hhb2RhaG9uZw==',
    policy: 'eGl4aWhhaGFrdWt1ZGFkYQ==',
    signature: 'ZGFob25nc2hhbw==',
  });
  const init = async () => {
    try {
      const result = await mockGetOSSData();
      setOSSData(result);
    } catch (error) {
      message.error(error);
    }
  };
  useEffect(() => {
    init();
  }, []);
  const handleChange = ({ fileList }) => {
    console.log('Aliyun OSS:', fileList);
    onChange?.([...fileList]);
  };
  const onRemove = (file) => {
    const files = (value || []).filter((v) => v.url !== file.url);
    if (onChange) {
      onChange(files);
    }
  };
  const getExtraData = (file) => ({
    key: file.url,
    OSSAccessKeyId: OSSData?.accessId,
    policy: OSSData?.policy,
    Signature: OSSData?.signature,
  });
  const beforeUpload = async (file) => {
    if (!OSSData) return false;
    const expire = Number(OSSData.expire) * 1000;
    if (expire < Date.now()) {
      await init();
    }
    const suffix = file.name.slice(file.name.lastIndexOf('.'));
    const filename = Date.now() + suffix;
    // @ts-ignore
    file.url = OSSData.dir + filename;
    return file;
  };
  const uploadProps = {
    name: 'file',
    fileList: value,
    action: OSSData?.host,
    onChange: handleChange,
    onRemove,
    data: getExtraData,
    beforeUpload,
  };
  return (
    <Upload {...uploadProps}>
      <Button icon={<UploadOutlined />}>Click to Upload</Button>
    </Upload>
  );
};
const App = () => (
  <Form
    labelCol={{
      span: 4,
    }}
  >
    <Form.Item label="Photos" name="photos">
      <AliyunOSSUpload />
    </Form.Item>
  </Form>
);
export default App;
`,description:"<p>\u4F7F\u7528\u963F\u91CC\u4E91 OSS \u4E0A\u4F20\u793A\u4F8B.</p>"}},{demo:{id:"components-upload-demo-file-type"},previewerProps:{debug:!0,title:"\u81EA\u5B9A\u4E49\u663E\u793A icon",filename:"components/upload/demo/file-type.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import {
  FileExcelTwoTone,
  FilePdfTwoTone,
  FileWordTwoTone,
  LoadingOutlined,
  PaperClipOutlined,
  PictureTwoTone,
  PlusOutlined,
} from '@ant-design/icons';
import { Modal, Upload } from 'antd';
const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
const App = () => {
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [fileList, setFileList] = useState([
    {
      uid: '-2',
      name: 'pdf.pdf',
      status: 'done',
      url: 'http://cdn07.foxitsoftware.cn/pub/foxit/cpdf/FoxitCompanyProfile.pdf',
    },
    {
      uid: '-3',
      name: 'doc.doc',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.doc',
    },
    {
      uid: '-4',
      name: 'image.png',
      status: 'error',
    },
    {
      uid: '-5',
      name: 'pdf.pdf',
      status: 'error',
    },
    {
      uid: '-6',
      name: 'doc.doc',
      status: 'error',
    },
  ]);
  const handleCancel = () => setPreviewOpen(false);
  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewOpen(true);
    setPreviewImage(file.url || file.preview);
  };
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const handleIconRender = (file, listType) => {
    const fileSufIconList = [
      {
        type: <FilePdfTwoTone />,
        suf: ['.pdf'],
      },
      {
        type: <FileExcelTwoTone />,
        suf: ['.xlsx', '.xls', '.csv'],
      },
      {
        type: <FileWordTwoTone />,
        suf: ['.doc', '.docx'],
      },
      {
        type: <PictureTwoTone />,
        suf: ['.webp', '.svg', '.png', '.gif', '.jpg', '.jpeg', '.jfif', '.bmp', '.dpg'],
      },
    ];
    // console.log(1, file, listType);
    let icon = file.status === 'uploading' ? <LoadingOutlined /> : <PaperClipOutlined />;
    if (listType === 'picture' || listType === 'picture-card' || listType === 'picture-circle') {
      if (listType === 'picture-card' && file.status === 'uploading') {
        icon = <LoadingOutlined />; // or icon = 'uploading...';
      } else {
        fileSufIconList.forEach((item) => {
          if (item.suf.includes(file.name.slice(file.name.lastIndexOf('.')))) {
            icon = item.type;
          }
        });
      }
    }
    return icon;
  };
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  return (
    <>
      <Upload
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        listType="picture-card"
        fileList={fileList}
        onPreview={handlePreview}
        onChange={handleChange}
        iconRender={handleIconRender}
      >
        {fileList.length >= 8 ? null : uploadButton}
      </Upload>
      <Modal open={previewOpen} footer={null} onCancel={handleCancel}>
        <img
          alt="example"
          style={{
            width: '100%',
          }}
          src={previewImage}
        />
      </Modal>
    </>
  );
};
export default App;
`,description:"<p>\u6839\u636E\u7C7B\u578B\u9ED8\u8BA4\u663E\u793A\u5BF9\u5E94 icon</p>"}},{demo:{id:"components-upload-demo-upload-custom-action-icon"},previewerProps:{title:"\u81EA\u5B9A\u4E49\u4EA4\u4E92\u56FE\u6807",filename:"components/upload/demo/upload-custom-action-icon.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { StarOutlined, UploadOutlined } from '@ant-design/icons';
import { Button, Upload } from 'antd';
const props = {
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  onChange({ file, fileList }) {
    if (file.status !== 'uploading') {
      console.log(file, fileList);
    }
  },
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      status: 'done',
      response: 'Server Error 500',
      // custom error message to show
      url: 'http://www.baidu.com/xxx.png',
    },
    {
      uid: '2',
      name: 'yyy.png',
      status: 'done',
      url: 'http://www.baidu.com/yyy.png',
    },
    {
      uid: '3',
      name: 'zzz.png',
      status: 'error',
      response: 'Server Error 500',
      // custom error message to show
      url: 'http://www.baidu.com/zzz.png',
    },
  ],
  showUploadList: {
    showDownloadIcon: true,
    downloadIcon: 'Download',
    showRemoveIcon: true,
    removeIcon: <StarOutlined onClick={(e) => console.log(e, 'custom removeIcon event')} />,
  },
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Upload</Button>
  </Upload>
);
export default App;
`,description:"<p>\u4F7F\u7528 <code>showUploadList</code> \u8BBE\u7F6E\u5217\u8868\u4EA4\u4E92\u56FE\u6807\u3002</p>"}},{demo:{id:"components-upload-demo-drag-sorting"},previewerProps:{title:"\u4E0A\u4F20\u5217\u8868\u62D6\u62FD\u6392\u5E8F",filename:"components/upload/demo/drag-sorting.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import { UploadOutlined } from '@ant-design/icons';
import { DndContext, PointerSensor, useSensor } from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import React, { useState } from 'react';
import { Button, Upload } from 'antd';
const DraggableUploadListItem = ({ originNode, file }) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: file.uid,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    cursor: 'move',
  };
  return (
    <div
      ref={setNodeRef}
      style={style}
      // prevent preview event when drag end
      className={isDragging ? 'is-dragging' : ''}
      {...attributes}
      {...listeners}
    >
      {/* hide error tooltip when dragging */}
      {file.status === 'error' && isDragging ? originNode.props.children : originNode}
    </div>
  );
};
const App = () => {
  const [fileList, setFileList] = useState([
    {
      uid: '-1',
      name: 'image1.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-2',
      name: 'image2.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-3',
      name: 'image3.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-4',
      name: 'image4.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
    {
      uid: '-5',
      name: 'image.png',
      status: 'error',
    },
  ]);
  const sensor = useSensor(PointerSensor, {
    activationConstraint: {
      distance: 10,
    },
  });
  const onDragEnd = ({ active, over }) => {
    if (active.id !== over?.id) {
      setFileList((prev) => {
        const activeIndex = prev.findIndex((i) => i.uid === active.id);
        const overIndex = prev.findIndex((i) => i.uid === over?.id);
        return arrayMove(prev, activeIndex, overIndex);
      });
    }
  };
  const onChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  return (
    <DndContext sensors={[sensor]} onDragEnd={onDragEnd}>
      <SortableContext items={fileList.map((i) => i.uid)} strategy={verticalListSortingStrategy}>
        <Upload
          action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
          fileList={fileList}
          onChange={onChange}
          itemRender={(originNode, file) => (
            <DraggableUploadListItem originNode={originNode} file={file} />
          )}
        >
          <Button icon={<UploadOutlined />}>Click to Upload</Button>
        </Upload>
      </SortableContext>
    </DndContext>
  );
};
export default App;
`,description:'<p>\u4F7F\u7528 <code>itemRender</code> \uFF0C\u6211\u4EEC\u53EF\u4EE5\u96C6\u6210 <a href="https://github.com/clauderic/dnd-kit">dnd-kit</a> \u6765\u5B9E\u73B0\u5BF9\u4E0A\u4F20\u5217\u8868\u62D6\u62FD\u6392\u5E8F\u3002</p>',style:`.is-dragging a {
  pointer-events: none;
}`}},{demo:{id:"components-upload-demo-crop-image"},previewerProps:{title:"\u4E0A\u4F20\u524D\u88C1\u5207\u56FE\u7247",filename:"components/upload/demo/crop-image.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import ImgCrop from 'antd-img-crop';
import React, { useState } from 'react';
import { Upload } from 'antd';
const App = () => {
  const [fileList, setFileList] = useState([
    {
      uid: '-1',
      name: 'image.png',
      status: 'done',
      url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
    },
  ]);
  const onChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  const onPreview = async (file) => {
    let src = file.url;
    if (!src) {
      src = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow?.document.write(image.outerHTML);
  };
  return (
    <ImgCrop rotationSlider>
      <Upload
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        listType="picture-card"
        fileList={fileList}
        onChange={onChange}
        onPreview={onPreview}
      >
        {fileList.length < 5 && '+ Upload'}
      </Upload>
    </ImgCrop>
  );
};
export default App;
`,description:'<p>\u914D\u5408 <a href="https://github.com/nanxiaobei/antd-img-crop">antd-img-crop</a> \u5B9E\u73B0\u4E0A\u4F20\u524D\u88C1\u5207\u56FE\u7247\u3002</p>'}},{demo:{id:"components-upload-demo-customize-progress-bar"},previewerProps:{title:"\u81EA\u5B9A\u4E49\u8FDB\u5EA6\u6761\u6837\u5F0F",filename:"components/upload/demo/customize-progress-bar.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { UploadOutlined } from '@ant-design/icons';
import { Button, message, Upload } from 'antd';
const props = {
  name: 'file',
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  headers: {
    authorization: 'authorization-text',
  },
  onChange(info) {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      message.success(\`\${info.file.name} file uploaded successfully\`);
    } else if (info.file.status === 'error') {
      message.error(\`\${info.file.name} file upload failed.\`);
    }
  },
  progress: {
    strokeColor: {
      '0%': '#108ee9',
      '100%': '#87d068',
    },
    strokeWidth: 3,
    format: (percent) => percent && \`\${parseFloat(percent.toFixed(2))}%\`,
  },
};
const App = () => (
  <Upload {...props}>
    <Button icon={<UploadOutlined />}>Click to Upload</Button>
  </Upload>
);
export default App;
`,description:"<p>\u4F7F\u7528 <code>progress</code> \u5C5E\u6027\u81EA\u5B9A\u4E49\u8FDB\u5EA6\u6761\u6837\u5F0F\u3002</p>"}},{demo:{id:"components-upload-demo-component-token"},previewerProps:{debug:!0,title:"\u7EC4\u4EF6 Token",filename:"components/upload/demo/component-token.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import { UploadOutlined } from '@ant-design/icons';
import React from 'react';
import { Button, ConfigProvider, Upload } from 'antd';
const props = {
  action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
  onChange({ file, fileList }) {
    if (file.status !== 'uploading') {
      console.log(file, fileList);
    }
  },
  defaultFileList: [
    {
      uid: '1',
      name: 'xxx.png',
      status: 'uploading',
      url: 'http://www.baidu.com/xxx.png',
      percent: 33,
    },
    {
      uid: '2',
      name: 'yyy.png',
      status: 'done',
      url: 'http://www.baidu.com/yyy.png',
    },
    {
      uid: '3',
      name: 'zzz.png',
      status: 'error',
      response: 'Server Error 500',
      // custom error message to show
      url: 'http://www.baidu.com/zzz.png',
    },
  ],
};
const App = () => (
  <ConfigProvider
    theme={{
      components: {
        Upload: {
          actionsColor: 'yellow',
        },
      },
    }}
  >
    <Upload {...props}>
      <Button icon={<UploadOutlined />}>Upload</Button>
    </Upload>
  </ConfigProvider>
);
export default App;
`,description:"<p>Component Token Debug.</p>"}},{demo:{id:"components-upload-demo-debug-disabled"},previewerProps:{debug:!0,title:"Debug Disabled Styles",filename:"components/upload/demo/debug-disabled.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { InboxOutlined, PlusOutlined, UploadOutlined } from '@ant-design/icons';
import { Button, Space, Upload } from 'antd';
const { Dragger } = Upload;
const fileList = [
  {
    uid: '-1',
    name: 'image.png',
    status: 'done',
    url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
  },
  {
    uid: '-2',
    name: 'image.png',
    status: 'done',
    url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
  },
  {
    uid: '-xxx',
    percent: 50,
    name: 'image.png',
    status: 'uploading',
    url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
  },
  {
    uid: '-5',
    name: 'image.png',
    status: 'error',
  },
];
const App = () => {
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  return (
    <Space direction="vertical">
      <Upload disabled>Click Text to Upload</Upload>
      <Upload disabled>
        <Button icon={<UploadOutlined />}>Click to Upload</Button>
      </Upload>
      <Upload name="avatar" listType="picture-card" fileList={fileList} disabled>
        {uploadButton}
      </Upload>
      <Upload name="avatar" listType="picture-circle" fileList={fileList} disabled>
        {uploadButton}
      </Upload>
      <Dragger disabled>
        <p className="ant-upload-drag-icon">
          <InboxOutlined />
        </p>
        <p className="ant-upload-text">Click or drag file to this area to upload</p>
        <p className="ant-upload-hint">
          Support for a single or bulk upload. Strictly prohibited from uploading company data or
          other banned files.
        </p>
      </Dragger>
    </Space>
  );
};
export default App;
`,description:"<p>Disabled Style Debug.</p>"}}]}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"api",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#api",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"API"]}),(0,e.jsxs)("p",{children:[t[5].value,(0,e.jsx)(r.Z,{to:"/docs/react/common-props",sourceType:"Link",children:t[6].value})]}),(0,e.jsxs)(o.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[7].value}),(0,e.jsx)("th",{children:t[8].value}),(0,e.jsx)("th",{children:t[9].value}),(0,e.jsx)("th",{children:t[10].value}),(0,e.jsx)("th",{children:t[11].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[12].value}),(0,e.jsxs)("td",{children:[t[13].value,(0,e.jsx)(r.Z,{href:"https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file#accept",sourceType:"a",children:t[14].value})]}),(0,e.jsx)("td",{children:t[15].value}),(0,e.jsx)("td",{children:t[16].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[17].value}),(0,e.jsx)("td",{children:t[18].value}),(0,e.jsx)("td",{children:t[19].value}),(0,e.jsx)("td",{children:t[20].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[21].value}),(0,e.jsxs)("td",{children:[t[22].value,(0,e.jsx)("code",{children:t[23].value}),t[24].value,(0,e.jsx)("code",{children:t[25].value}),t[26].value,(0,e.jsx)("code",{children:t[27].value}),t[28].value,(0,e.jsx)("code",{children:t[29].value}),t[30].value,(0,e.jsx)("strong",{children:t[31].value})]}),(0,e.jsxs)("td",{children:[t[32].value,(0,e.jsx)("code",{children:t[33].value})]}),(0,e.jsx)("td",{children:t[34].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[35].value}),(0,e.jsx)("td",{children:t[36].value}),(0,e.jsx)("td",{children:t[37].value}),(0,e.jsx)("td",{children:t[38].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[39].value}),(0,e.jsx)("td",{children:t[40].value}),(0,e.jsx)("td",{children:t[41].value}),(0,e.jsx)("td",{children:t[42].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[43].value}),(0,e.jsx)("td",{children:t[44].value}),(0,e.jsx)("td",{children:t[45].value}),(0,e.jsx)("td",{children:t[46].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[47].value}),(0,e.jsxs)("td",{children:[t[48].value,(0,e.jsx)(r.Z,{href:"https://caniuse.com/#feat=input-file-directory",sourceType:"a",children:t[49].value}),t[50].value]}),(0,e.jsx)("td",{children:t[51].value}),(0,e.jsx)("td",{children:t[52].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[53].value}),(0,e.jsx)("td",{children:t[54].value}),(0,e.jsx)("td",{children:t[55].value}),(0,e.jsx)("td",{children:t[56].value}),(0,e.jsx)("td",{children:t[57].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[58].value}),(0,e.jsxs)("td",{children:[t[59].value,(0,e.jsx)("code",{children:t[60].value}),t[61].value,(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/issues/2423",sourceType:"a",children:t[62].value})]}),(0,e.jsxs)("td",{children:[(0,e.jsx)(r.Z,{to:"#uploadfile",sourceType:"Link",children:t[63].value}),t[64].value]}),(0,e.jsx)("td",{children:t[65].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[66].value}),(0,e.jsx)("td",{children:t[67].value}),(0,e.jsx)("td",{children:t[68].value}),(0,e.jsx)("td",{children:t[69].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[70].value}),(0,e.jsx)("td",{children:t[71].value}),(0,e.jsx)("td",{children:t[72].value}),(0,e.jsx)("td",{children:t[73].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[74].value}),(0,e.jsx)("td",{children:t[75].value}),(0,e.jsx)("td",{children:t[76].value}),(0,e.jsx)("td",{children:(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/blob/4ad5830eecfb87471cd8ac588c5d992862b70770/components/upload/utils.tsx#L47-L68",sourceType:"a",children:t[77].value})}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[78].value}),(0,e.jsx)("td",{children:t[79].value}),(0,e.jsx)("td",{children:t[80].value}),(0,e.jsx)("td",{children:t[81].value}),(0,e.jsx)("td",{children:t[82].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[83].value}),(0,e.jsxs)("td",{children:[t[84].value,(0,e.jsx)("code",{children:t[85].value}),t[86].value,(0,e.jsx)("code",{children:t[87].value}),t[88].value,(0,e.jsx)("code",{children:t[89].value}),t[90].value,(0,e.jsx)("code",{children:t[91].value})]}),(0,e.jsx)("td",{children:t[92].value}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[93].value})}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[94].value}),t[95].value]})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[96].value}),(0,e.jsx)("td",{children:t[97].value}),(0,e.jsx)("td",{children:t[98].value}),(0,e.jsx)("td",{children:t[99].value}),(0,e.jsx)("td",{children:t[100].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[101].value}),(0,e.jsx)("td",{children:t[102].value}),(0,e.jsx)("td",{children:t[103].value}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[104].value})}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[105].value}),(0,e.jsxs)("td",{children:[t[106].value,(0,e.jsx)("code",{children:t[107].value}),t[108].value]}),(0,e.jsx)("td",{children:t[109].value}),(0,e.jsx)("td",{children:t[110].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[111].value}),(0,e.jsx)("td",{children:t[112].value}),(0,e.jsx)("td",{children:t[113].value}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[114].value})}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[115].value}),(0,e.jsx)("td",{children:t[116].value}),(0,e.jsx)("td",{children:t[117].value}),(0,e.jsx)("td",{children:t[118].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[119].value}),(0,e.jsx)("td",{children:t[120].value}),(0,e.jsx)("td",{children:t[121].value}),(0,e.jsx)("td",{children:t[122].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[123].value}),(0,e.jsx)("td",{children:t[124].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)(r.Z,{to:"/components/progress-cn#api",sourceType:"Link",children:t[125].value}),t[126].value,(0,e.jsx)("code",{children:t[127].value}),t[128].value]}),(0,e.jsx)("td",{children:t[129].value}),(0,e.jsx)("td",{children:t[130].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[131].value}),(0,e.jsxs)("td",{children:[t[132].value,(0,e.jsx)("code",{children:t[133].value}),t[134].value,(0,e.jsx)("code",{children:t[135].value}),t[136].value,(0,e.jsx)("code",{children:t[137].value}),t[138].value,(0,e.jsx)("code",{children:t[139].value}),t[140].value,(0,e.jsx)("code",{children:t[141].value})]}),(0,e.jsx)("td",{children:t[142].value}),(0,e.jsx)("td",{children:t[143].value}),(0,e.jsx)("td",{children:t[144].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[145].value}),(0,e.jsx)("td",{children:t[146].value}),(0,e.jsx)("td",{children:t[147].value}),(0,e.jsx)("td",{children:t[148].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[149].value}),(0,e.jsxs)("td",{children:[t[150].value,(0,e.jsx)(r.Z,{to:"#onchange",sourceType:"Link",children:t[151].value})]}),(0,e.jsx)("td",{children:t[152].value}),(0,e.jsx)("td",{children:t[153].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[154].value}),(0,e.jsx)("td",{children:t[155].value}),(0,e.jsx)("td",{children:t[156].value}),(0,e.jsx)("td",{children:t[157].value}),(0,e.jsx)("td",{children:t[158].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[159].value}),(0,e.jsx)("td",{children:t[160].value}),(0,e.jsx)("td",{children:t[161].value}),(0,e.jsx)("td",{children:t[162].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[163].value}),(0,e.jsx)("td",{children:t[164].value}),(0,e.jsx)("td",{children:t[165].value}),(0,e.jsx)("td",{children:t[166].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[167].value}),(0,e.jsx)("td",{children:t[168].value}),(0,e.jsx)("td",{children:t[169].value}),(0,e.jsx)("td",{children:t[170].value}),(0,e.jsx)("td",{})]})]})]}),(0,e.jsxs)("h3",{id:"uploadfile",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#uploadfile",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"UploadFile"]}),(0,e.jsx)("p",{children:t[171].value}),(0,e.jsxs)(o.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[172].value}),(0,e.jsx)("th",{children:t[173].value}),(0,e.jsx)("th",{children:t[174].value}),(0,e.jsx)("th",{children:t[175].value}),(0,e.jsx)("th",{children:t[176].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[177].value}),(0,e.jsx)("td",{children:t[178].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[179].value}),t[180].value,(0,e.jsx)("code",{children:t[181].value}),t[182].value,(0,e.jsx)("code",{children:t[183].value})]}),(0,e.jsx)("td",{children:t[184].value}),(0,e.jsx)("td",{children:t[185].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[186].value}),(0,e.jsx)("td",{children:t[187].value}),(0,e.jsx)("td",{children:t[188].value}),(0,e.jsx)("td",{children:t[189].value}),(0,e.jsx)("td",{children:t[190].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[191].value}),(0,e.jsx)("td",{children:t[192].value}),(0,e.jsx)("td",{children:t[193].value}),(0,e.jsx)("td",{children:t[194].value}),(0,e.jsx)("td",{children:t[195].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[196].value}),(0,e.jsx)("td",{children:t[197].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[198].value}),t[199].value,(0,e.jsx)("code",{children:t[200].value}),t[201].value,(0,e.jsx)("code",{children:t[202].value}),t[203].value,(0,e.jsx)("code",{children:t[204].value})]}),(0,e.jsx)("td",{children:t[205].value}),(0,e.jsx)("td",{children:t[206].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[207].value}),(0,e.jsx)("td",{children:t[208].value}),(0,e.jsx)("td",{children:t[209].value}),(0,e.jsx)("td",{children:t[210].value}),(0,e.jsx)("td",{children:t[211].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[212].value}),(0,e.jsx)("td",{children:t[213].value}),(0,e.jsx)("td",{children:t[214].value}),(0,e.jsx)("td",{children:t[215].value}),(0,e.jsx)("td",{children:t[216].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[217].value}),(0,e.jsx)("td",{children:t[218].value}),(0,e.jsx)("td",{children:t[219].value}),(0,e.jsx)("td",{children:t[220].value}),(0,e.jsx)("td",{children:t[221].value})]})]})]}),(0,e.jsxs)("h3",{id:"onchange",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#onchange",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"onChange"]}),(0,e.jsx)("blockquote",{children:(0,e.jsx)("p",{children:t[222].value})}),(0,e.jsx)("p",{children:t[223].value}),(0,e.jsx)(s.Z,{lang:"jsx",children:t[224].value}),(0,e.jsxs)("ol",{children:[(0,e.jsxs)("li",{children:[(0,e.jsxs)("p",{children:[(0,e.jsx)("code",{children:t[225].value}),t[226].value]}),(0,e.jsx)(s.Z,{lang:"jsx",children:t[227].value})]}),(0,e.jsx)("li",{children:(0,e.jsxs)("p",{children:[(0,e.jsx)("code",{children:t[228].value}),t[229].value]})}),(0,e.jsx)("li",{children:(0,e.jsxs)("p",{children:[(0,e.jsx)("code",{children:t[230].value}),t[231].value]})})]}),(0,e.jsxs)("h2",{id:"\u4E3B\u9898\u53D8\u91CFdesign-token",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4E3B\u9898\u53D8\u91CFdesign-token",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4E3B\u9898\u53D8\u91CF\uFF08Design Token\uFF09"]})]}),(0,e.jsx)(l.Z,{component:"Upload"}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"faq",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#faq",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"FAQ"]}),(0,e.jsxs)("h3",{id:"\u670D\u52A1\u7AEF\u5982\u4F55\u5B9E\u73B0",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u670D\u52A1\u7AEF\u5982\u4F55\u5B9E\u73B0",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u670D\u52A1\u7AEF\u5982\u4F55\u5B9E\u73B0\uFF1F"]}),(0,e.jsxs)("ul",{children:[(0,e.jsxs)("li",{children:[t[232].value,(0,e.jsx)(r.Z,{href:"https://github.com/blueimp/jQuery-File-Upload/wiki#server-side",sourceType:"a",children:t[233].value}),t[234].value]}),(0,e.jsxs)("li",{children:[t[235].value,(0,e.jsx)(r.Z,{href:"https://github.com/react-component/upload/blob/master/server.js",sourceType:"a",children:t[236].value}),t[237].value]})]}),(0,e.jsxs)("h3",{id:"\u5982\u4F55\u663E\u793A\u4E0B\u8F7D\u94FE\u63A5",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u5982\u4F55\u663E\u793A\u4E0B\u8F7D\u94FE\u63A5",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u5982\u4F55\u663E\u793A\u4E0B\u8F7D\u94FE\u63A5\uFF1F"]}),(0,e.jsxs)("p",{children:[t[238].value,(0,e.jsx)("code",{children:t[239].value}),t[240].value,(0,e.jsx)("code",{children:t[241].value}),t[242].value]}),(0,e.jsxs)("h3",{id:"customrequest-\u600E\u4E48\u4F7F\u7528",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#customrequest-\u600E\u4E48\u4F7F\u7528",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),(0,e.jsx)("code",{children:t[243].value})," \u600E\u4E48\u4F7F\u7528\uFF1F"]}),(0,e.jsxs)("p",{children:[t[244].value,(0,e.jsx)(r.Z,{href:"https://github.com/react-component/upload#customrequest",sourceType:"a",children:t[245].value}),t[246].value]}),(0,e.jsxs)("h3",{id:"\u4E3A\u4F55-filelist-\u53D7\u63A7\u65F6\u4E0A\u4F20\u4E0D\u5728\u5217\u8868\u4E2D\u7684\u6587\u4EF6\u4E0D\u4F1A\u89E6\u53D1-onchange-\u540E\u7EED\u7684-status-\u66F4\u65B0\u4E8B\u4EF6",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4E3A\u4F55-filelist-\u53D7\u63A7\u65F6\u4E0A\u4F20\u4E0D\u5728\u5217\u8868\u4E2D\u7684\u6587\u4EF6\u4E0D\u4F1A\u89E6\u53D1-onchange-\u540E\u7EED\u7684-status-\u66F4\u65B0\u4E8B\u4EF6",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4E3A\u4F55 ",(0,e.jsx)("code",{children:t[247].value})," \u53D7\u63A7\u65F6\uFF0C\u4E0A\u4F20\u4E0D\u5728\u5217\u8868\u4E2D\u7684\u6587\u4EF6\u4E0D\u4F1A\u89E6\u53D1 ",(0,e.jsx)("code",{children:t[248].value})," \u540E\u7EED\u7684 ",(0,e.jsx)("code",{children:t[249].value})," \u66F4\u65B0\u4E8B\u4EF6\uFF1F"]}),(0,e.jsxs)("p",{children:[(0,e.jsx)("code",{children:t[250].value}),t[251].value,(0,e.jsx)("code",{children:t[252].value}),t[253].value,(0,e.jsx)("code",{children:t[254].value}),t[255].value]}),(0,e.jsxs)("h3",{id:"onchange-\u4E3A\u4EC0\u4E48\u6709\u65F6\u5019\u8FD4\u56DE-file-\u6709\u65F6\u5019\u8FD4\u56DE--originfileobj-file-",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#onchange-\u4E3A\u4EC0\u4E48\u6709\u65F6\u5019\u8FD4\u56DE-file-\u6709\u65F6\u5019\u8FD4\u56DE--originfileobj-file-",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),(0,e.jsx)("code",{children:t[256].value})," \u4E3A\u4EC0\u4E48\u6709\u65F6\u5019\u8FD4\u56DE File \u6709\u65F6\u5019\u8FD4\u56DE { originFileObj: File }\uFF1F"]}),(0,e.jsxs)("p",{children:[t[257].value,(0,e.jsx)("code",{children:t[258].value}),t[259].value,(0,e.jsx)("code",{children:t[260].value}),t[261].value,(0,e.jsx)("code",{children:t[262].value}),t[263].value,(0,e.jsx)("code",{children:t[264].value}),t[265].value,(0,e.jsx)("code",{children:t[266].value}),t[267].value,(0,e.jsx)("code",{children:t[268].value}),t[269].value]}),(0,e.jsxs)("h3",{id:"\u4E3A\u4F55\u6709\u65F6-chrome-\u70B9\u51FB-upload-\u65E0\u6CD5\u5F39\u51FA\u6587\u4EF6\u9009\u62E9\u6846",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u4E3A\u4F55\u6709\u65F6-chrome-\u70B9\u51FB-upload-\u65E0\u6CD5\u5F39\u51FA\u6587\u4EF6\u9009\u62E9\u6846",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u4E3A\u4F55\u6709\u65F6 Chrome \u70B9\u51FB Upload \u65E0\u6CD5\u5F39\u51FA\u6587\u4EF6\u9009\u62E9\u6846\uFF1F"]}),(0,e.jsxs)("p",{children:[t[270].value,(0,e.jsx)("code",{children:t[271].value}),t[272].value,(0,e.jsx)("code",{children:t[273].value}),t[274].value]}),(0,e.jsxs)("p",{children:[t[275].value,(0,e.jsx)("code",{children:t[276].value}),t[277].value]}),(0,e.jsxs)("ul",{children:[(0,e.jsx)("li",{children:(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/issues/32672",sourceType:"a",children:t[278].value})}),(0,e.jsx)("li",{children:(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/issues/32913",sourceType:"a",children:t[279].value})}),(0,e.jsx)("li",{children:(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/issues/33988",sourceType:"a",children:t[280].value})})]}),(0,e.jsxs)("h3",{id:"\u6587\u4EF6\u5939\u4E0A\u4F20\u5728-safari-\u4ECD\u7136\u53EF\u4EE5\u9009\u4E2D\u6587\u4EF6",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#\u6587\u4EF6\u5939\u4E0A\u4F20\u5728-safari-\u4ECD\u7136\u53EF\u4EE5\u9009\u4E2D\u6587\u4EF6",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"\u6587\u4EF6\u5939\u4E0A\u4F20\u5728 Safari \u4ECD\u7136\u53EF\u4EE5\u9009\u4E2D\u6587\u4EF6?"]}),(0,e.jsxs)("p",{children:[t[281].value,(0,e.jsx)("code",{children:t[282].value}),t[283].value,(0,e.jsx)("code",{children:t[284].value}),t[285].value,(0,e.jsx)(r.Z,{href:"https://stackoverflow.com/q/55649945/3040605",sourceType:"a",children:t[286].value}),t[287].value,(0,e.jsx)("code",{children:t[288].value}),t[289].value]}),(0,e.jsx)(s.Z,{lang:"jsx",children:t[290].value})]})]})})}i.default=p}}]);
