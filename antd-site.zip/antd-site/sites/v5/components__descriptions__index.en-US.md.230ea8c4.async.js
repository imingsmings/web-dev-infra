"use strict";(self.webpackChunkantd=self.webpackChunkantd||[]).push([[12599],{351622:function(m,s,n){n.r(s);var u=n(863942),g=n(502143),y=n(968521),h=n(702951),b=n(521587),a=n(199100),i=n(828089),j=n(825673),k=n(902068),v=n(574399),x=n(316073),_=n(24628),f=n(719260),D=n(956140),c=n(127179),l=n(905388),w=n(245583),C=n(606965),z=n(268696),P=n(587302),r=n(424128),E=n(249706),R=n(795127),M=n(116846),I=n(720538),B=n(212039),U=n(73024),O=n(553913),o=n(385956),A=n(667294),e=n(785893);function d(){var p=(0,o.useRouteMeta)(),t=p.texts;return(0,e.jsx)(o.DumiPage,{children:(0,e.jsxs)(e.Fragment,{children:[(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsx)("p",{children:t[0].value}),(0,e.jsxs)("h2",{id:"when-to-use",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#when-to-use",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"When To Use"]}),(0,e.jsx)("p",{children:t[1].value}),(0,e.jsx)(a.Z,{lang:"tsx",children:t[2].value}),(0,e.jsxs)("h2",{id:"examples",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#examples",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Examples"]})]}),(0,e.jsx)(l.Z,{items:[{demo:{id:"descriptions-demo-basic"},previewerProps:{title:"Basic",filename:"components/descriptions/demo/basic.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Descriptions } from 'antd';
const items = [
  {
    key: '1',
    label: 'UserName',
    children: 'Zhou Maomao',
  },
  {
    key: '2',
    label: 'Telephone',
    children: '1810000000',
  },
  {
    key: '3',
    label: 'Live',
    children: 'Hangzhou, Zhejiang',
  },
  {
    key: '4',
    label: 'Remark',
    children: 'empty',
  },
  {
    key: '5',
    label: 'Address',
    children: 'No. 18, Wantang Road, Xihu District, Hangzhou, Zhejiang, China',
  },
];
const App = () => <Descriptions title="User Info" items={items} />;
export default App;
`,description:"<p>Simplest Usage.</p>"}},{demo:{id:"descriptions-demo-border"},previewerProps:{title:"border",filename:"components/descriptions/demo/border.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Badge, Descriptions } from 'antd';
const items = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing Mode',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Automatic Renewal',
    children: 'YES',
  },
  {
    key: '4',
    label: 'Order time',
    children: '2018-04-24 18:00:00',
  },
  {
    key: '5',
    label: 'Usage Time',
    children: '2019-04-24 18:00:00',
    span: 2,
  },
  {
    key: '6',
    label: 'Status',
    children: <Badge status="processing" text="Running" />,
    span: 3,
  },
  {
    key: '7',
    label: 'Negotiated Amount',
    children: '$80.00',
  },
  {
    key: '8',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '9',
    label: 'Official Receipts',
    children: '$60.00',
  },
  {
    key: '10',
    label: 'Config Info',
    children: (
      <>
        Data disk type: MongoDB
        <br />
        Database version: 3.4
        <br />
        Package: dds.mongo.mid
        <br />
        Storage space: 10 GB
        <br />
        Replication factor: 3
        <br />
        Region: East China 1
        <br />
      </>
    ),
  },
];
const App = () => <Descriptions title="User Info" bordered items={items} />;
export default App;
`,description:"<p>Descriptions with border and background color.</p>"}},{demo:{id:"descriptions-demo-text"},previewerProps:{debug:!0,title:"border",filename:"components/descriptions/demo/text.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Badge, Descriptions, Table } from 'antd';
const dataSource = [
  {
    key: '1',
    name: '\u80E1\u5F66\u658C',
    age: 32,
    address: '\u897F\u6E56\u533A\u6E56\u5E95\u516C\u56ED1\u53F7',
  },
  {
    key: '2',
    name: '\u80E1\u5F66\u7956',
    age: 42,
    address: '\u897F\u6E56\u533A\u6E56\u5E95\u516C\u56ED1\u53F7',
  },
];
const columns = [
  {
    title: '\u59D3\u540D',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '\u5E74\u9F84',
    dataIndex: 'age',
    key: 'age',
  },
  {
    title: '\u4F4F\u5740',
    dataIndex: 'address',
    key: 'address',
  },
];
const items = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: (
      <div
        style={{
          display: 'flex',
        }}
      >
        Billing Mode
      </div>
    ),
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Automatic Renewal',
    children: 'YES',
  },
  {
    key: '4',
    label: 'Order time',
    children: '2018-04-24 18:00:00',
  },
  {
    key: '5',
    label: 'Usage Time',
    span: 2,
    children: '2019-04-24 18:00:00',
  },
  {
    key: '6',
    label: 'Status',
    span: 3,
    children: <Badge status="processing" text="Running" />,
  },
  {
    key: '7',
    label: 'Negotiated Amount',
    children: '$80.00',
  },
  {
    key: '8',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '9',
    label: 'Official Receipts',
    children: '$60.00',
  },
  {
    key: '10',
    label: 'Config Info',
    children: (
      <>
        Data disk type: MongoDB
        <br />
        Database version: 3.4
        <br />
        Package: dds.mongo.mid
        <br />
        Storage space: 10 GB
        <br />
        Replication factor: 3
        <br />
        Region: East China 1
        <br />
      </>
    ),
  },
  {
    key: '11',
    label: 'Official Receipts',
    children: '$60.00',
  },
  {
    key: '12',
    label: 'Config Info',
    children: <Table size="small" pagination={false} dataSource={dataSource} columns={columns} />,
  },
];
const App = () => <Descriptions title="User Info" column={2} items={items} />;
export default App;
`,description:"<p>Descriptions with border and background color.</p>"}},{demo:{id:"descriptions-demo-size"},previewerProps:{title:"Custom size",filename:"components/descriptions/demo/size.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { Button, Descriptions, Radio } from 'antd';
const borderedItems = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Time',
    children: '18:00:00',
  },
  {
    key: '4',
    label: 'Amount',
    children: '$80.00',
  },
  {
    key: '5',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '6',
    label: 'Official',
    children: '$60.00',
  },
  {
    key: '7',
    label: 'Config Info',
    children: (
      <>
        Data disk type: MongoDB
        <br />
        Database version: 3.4
        <br />
        Package: dds.mongo.mid
        <br />
        Storage space: 10 GB
        <br />
        Replication factor: 3
        <br />
        Region: East China 1
        <br />
      </>
    ),
  },
];
const items = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Time',
    children: '18:00:00',
  },
  {
    key: '4',
    label: 'Amount',
    children: '$80.00',
  },
  {
    key: '5',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '6',
    label: 'Official',
    children: '$60.00',
  },
];
const App = () => {
  const [size, setSize] = useState('default');
  const onChange = (e) => {
    console.log('size checked', e.target.value);
    setSize(e.target.value);
  };
  return (
    <div>
      <Radio.Group onChange={onChange} value={size}>
        <Radio value="default">default</Radio>
        <Radio value="middle">middle</Radio>
        <Radio value="small">small</Radio>
      </Radio.Group>
      <br />
      <br />
      <Descriptions
        bordered
        title="Custom Size"
        size={size}
        extra={<Button type="primary">Edit</Button>}
        items={borderedItems}
      />
      <br />
      <br />
      <Descriptions
        title="Custom Size"
        size={size}
        extra={<Button type="primary">Edit</Button>}
        items={items}
      />
    </div>
  );
};
export default App;
`,description:"<p>Custom sizes to fit in a variety of containers.</p>"}},{demo:{id:"descriptions-demo-responsive"},previewerProps:{title:"responsive",filename:"components/descriptions/demo/responsive.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Descriptions } from 'antd';
const items = [
  {
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    label: 'Billing',
    children: 'Prepaid',
  },
  {
    label: 'Time',
    children: '18:00:00',
  },
  {
    label: 'Amount',
    children: '$80.00',
  },
  {
    label: 'Discount',
    span: {
      xl: 2,
      xxl: 2,
    },
    children: '$20.00',
  },
  {
    label: 'Official',
    span: {
      xl: 2,
      xxl: 2,
    },
    children: '$60.00',
  },
  {
    label: 'Config Info',
    span: {
      xs: 1,
      sm: 2,
      md: 3,
      lg: 3,
      xl: 2,
      xxl: 2,
    },
    children: (
      <>
        Data disk type: MongoDB
        <br />
        Database version: 3.4
        <br />
        Package: dds.mongo.mid
      </>
    ),
  },
  {
    label: 'Hardware Info',
    span: {
      xs: 1,
      sm: 2,
      md: 3,
      lg: 3,
      xl: 2,
      xxl: 2,
    },
    children: (
      <>
        CPU: 6 Core 3.5 GHz
        <br />
        Storage space: 10 GB
        <br />
        Replication factor: 3
        <br />
        Region: East China 1
      </>
    ),
  },
];
const App = () => (
  <Descriptions
    title="Responsive Descriptions"
    bordered
    column={{
      xs: 1,
      sm: 2,
      md: 3,
      lg: 3,
      xl: 4,
      xxl: 4,
    }}
    items={items}
  />
);
export default App;
`,description:"<p>Responsive configuration enables perfect presentation on small screen devices.</p>"}},{demo:{id:"descriptions-demo-vertical"},previewerProps:{title:"Vertical",filename:"components/descriptions/demo/vertical.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Descriptions } from 'antd';
const items = [
  {
    key: '1',
    label: 'UserName',
    children: 'Zhou Maomao',
  },
  {
    key: '2',
    label: 'Telephone',
    children: '1810000000',
  },
  {
    key: '3',
    label: 'Live',
    children: 'Hangzhou, Zhejiang',
  },
  {
    key: '4',
    label: 'Address',
    span: 2,
    children: 'No. 18, Wantang Road, Xihu District, Hangzhou, Zhejiang, China',
  },
  {
    key: '5',
    label: 'Remark',
    children: 'empty',
  },
];
const App = () => <Descriptions title="User Info" layout="vertical" items={items} />;
export default App;
`,description:"<p>Simplest Usage.</p>"}},{demo:{id:"descriptions-demo-vertical-border"},previewerProps:{title:"Vertical border",filename:"components/descriptions/demo/vertical-border.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Badge, Descriptions } from 'antd';
const items = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing Mode',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Automatic Renewal',
    children: 'YES',
  },
  {
    key: '4',
    label: 'Order time',
    children: '2018-04-24 18:00:00',
  },
  {
    key: '5',
    label: 'Usage Time',
    span: 2,
    children: '2019-04-24 18:00:00',
  },
  {
    key: '6',
    label: 'Status',
    span: 3,
    children: <Badge status="processing" text="Running" />,
  },
  {
    key: '7',
    label: 'Negotiated Amount',
    children: '$80.00',
  },
  {
    key: '8',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '9',
    label: 'Official Receipts',
    children: '$60.00',
  },
  {
    key: '10',
    label: 'Config Info',
    children: (
      <>
        Data disk type: MongoDB
        <br />
        Database version: 3.4
        <br />
        Package: dds.mongo.mid
        <br />
        Storage space: 10 GB
        <br />
        Replication factor: 3
        <br />
        Region: East China 1
        <br />
      </>
    ),
  },
];
const App = () => <Descriptions title="User Info" layout="vertical" bordered items={items} />;
export default App;
`,description:"<p>Descriptions with border and background color.</p>"}},{demo:{id:"descriptions-demo-style"},previewerProps:{debug:!0,title:"Customize label & wrapper style",filename:"components/descriptions/demo/style.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { Descriptions, Divider, Radio, Switch } from 'antd';
const labelStyle = {
  background: 'red',
};
const contentStyle = {
  background: 'green',
};
const items = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
    labelStyle,
    contentStyle,
  },
  {
    key: '2',
    label: 'Billing Mode',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Automatic Renewal',
    children: 'YES',
  },
];
const rootStyleItems = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing Mode',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Automatic Renewal',
    children: 'YES',
    labelStyle: {
      color: 'orange',
    },
    contentStyle: {
      color: 'blue',
    },
  },
];
const App = () => {
  const [border, setBorder] = useState(true);
  const [layout, setLayout] = useState('horizontal');
  return (
    <>
      <Switch
        checkedChildren="Border"
        unCheckedChildren="No Border"
        checked={border}
        onChange={(e) => setBorder(e)}
      />
      <Divider />
      <Radio.Group onChange={(e) => setLayout(e.target.value)} value={layout}>
        <Radio value="horizontal">horizontal</Radio>
        <Radio value="vertical">vertical</Radio>
      </Radio.Group>
      <Divider />
      <Descriptions title="User Info" bordered={border} layout={layout} items={items} />
      <Divider />
      <Descriptions
        title="Root style"
        labelStyle={labelStyle}
        contentStyle={contentStyle}
        bordered={border}
        layout={layout}
        items={rootStyleItems}
      />
    </>
  );
};
export default App;
`,description:"<p>Customize label &#x26; wrapper style</p>"}},{demo:{id:"descriptions-demo-jsx"},previewerProps:{debug:!0,title:"JSX demo",filename:"components/descriptions/demo/jsx.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React from 'react';
import { Descriptions } from 'antd';
const App = () => (
  <Descriptions title="User Info">
    <Descriptions.Item label="UserName">Zhou Maomao</Descriptions.Item>
    <Descriptions.Item label="Telephone">1810000000</Descriptions.Item>
    <Descriptions.Item label="Live">Hangzhou, Zhejiang</Descriptions.Item>
    <Descriptions.Item label="Remark">empty</Descriptions.Item>
    <Descriptions.Item label="Address">
      No. 18, Wantang Road, Xihu District, Hangzhou, Zhejiang, China
    </Descriptions.Item>
  </Descriptions>
);
export default App;
`,description:"<p>JSX Style Demo.</p>"}},{demo:{id:"descriptions-demo-component-token"},previewerProps:{debug:!0,title:"Component Token",filename:"components/descriptions/demo/component-token.tsx",pkgDependencyList:{"@ant-design/compatible":"^5.1.2","@ant-design/happy-work-theme":"^1.0.0","@ant-design/tools":"^18.0.2","@antv/g6":"^4.8.23","@babel/eslint-plugin":"^7.22.10","@biomejs/biome":"^1.3.3","@codesandbox/sandpack-react":"^2.10.0","@dnd-kit/core":"^6.1.0","@dnd-kit/modifiers":"^7.0.0","@dnd-kit/sortable":"^8.0.0","@dnd-kit/utilities":"^3.2.2","@emotion/react":"^11.11.1","@emotion/server":"^11.11.0","@ianvs/prettier-plugin-sort-imports":"^4.1.1","@madccc/duplicate-package-checker-webpack-plugin":"^1.0.0","@qixian.cs/github-contributors-list":"^1.1.0","@size-limit/file":"^11.0.0","@stackblitz/sdk":"^1.9.0","@testing-library/dom":"^9.3.3","@testing-library/jest-dom":"^6.1.4","@testing-library/react":"^14.1.2","@testing-library/user-event":"^14.5.1","@types/ali-oss":"^6.16.11","@types/fs-extra":"^11.0.4","@types/gtag.js":"^0.0.18","@types/http-server":"^0.12.4","@types/inquirer":"^9.0.7","@types/isomorphic-fetch":"^0.0.39","@types/jest":"^29.5.10","@types/jest-axe":"^3.5.8","@types/jest-environment-puppeteer":"^5.0.6","@types/jest-image-snapshot":"^6.2.3","@types/jquery":"^3.5.29","@types/jsdom":"^21.1.6","@types/lodash":"^4.14.202","@types/node":"^20.10.0","@types/nprogress":"^0.2.3","@types/prismjs":"^1.26.3","@types/progress":"^2.0.7","@types/qs":"^6.9.10","@types/react":"^18.2.38","@types/react-copy-to-clipboard":"^5.0.7","@types/react-dom":"^18.2.17","@types/react-highlight-words":"^0.16.7","@types/react-resizable":"^3.0.7","@types/throttle-debounce":"^5.0.2","@types/warning":"^3.0.3","@typescript-eslint/eslint-plugin":"^6.12.0","@typescript-eslint/parser":"^6.12.0","ali-oss":"^6.18.1","antd-img-crop":"^4.17.0","antd-style":"^3.5.2","antd-token-previewer":"^2.0.5",chalk:"^4.0.0",cheerio:"1.0.0-rc.12","circular-dependency-plugin":"^5.2.2","cross-env":"^7.0.3","cross-fetch":"^4.0.0",crypto:"^1.0.1",dekko:"^0.2.1",dumi:"^2.3.0-alpha.9","dumi-plugin-color-chunk":"^1.0.4","esbuild-loader":"^4.0.2",eslint:"^8.54.0","eslint-config-airbnb":"^19.0.4","eslint-config-prettier":"^9.0.0","eslint-import-resolver-typescript":"^3.6.1","eslint-plugin-compat":"^4.2.0","eslint-plugin-import":"^2.29.0","eslint-plugin-jest":"^27.6.0","eslint-plugin-jsx-a11y":"^6.8.0","eslint-plugin-lodash":"^7.4.0","eslint-plugin-markdown":"^3.0.1","eslint-plugin-react":"^7.33.2","eslint-plugin-react-hooks":"^4.6.0","eslint-plugin-unicorn":"^49.0.0","fast-glob":"^3.3.2","fetch-jsonp":"^1.3.0","fs-extra":"^11.1.1","gh-pages":"^6.1.0",glob:"^10.3.10",html2sketch:"^1.0.2","http-server":"^14.1.1",husky:"^8.0.3","identity-obj-proxy":"^3.0.0",immer:"^10.0.3",inquirer:"^9.2.12","is-ci":"^3.0.1","isomorphic-fetch":"^3.0.0",jest:"^29.7.0","jest-axe":"^8.0.0","jest-canvas-mock":"^2.5.2","jest-environment-jsdom":"^29.7.0","jest-environment-node":"^29.7.0","jest-image-snapshot":"^6.2.0","jest-puppeteer":"^9.0.1",jquery:"^3.7.1",jsdom:"^23.0.0","jsonml-to-react-element":"^1.1.11","jsonml.js":"^0.1.0","lint-staged":"^15.1.0",lodash:"^4.17.21","lunar-typescript":"^1.6.13","lz-string":"^1.5.0",mockdate:"^3.0.5","node-notifier":"^10.0.1",nprogress:"^0.2.0",open:"^9.1.0",prettier:"^3.1.0","prettier-plugin-jsdoc":"^1.1.1","pretty-format":"^29.7.0",prismjs:"^1.29.0",progress:"^2.0.3",puppeteer:"^21.5.2",qs:"^6.11.2","rc-footer":"^0.6.8","rc-tween-one":"^3.0.6","rc-virtual-list":"^3.11.3",react:"^18.2.0","react-copy-to-clipboard":"^5.1.0","react-countup":"^6.5.0","react-dom":"^18.2.0","react-draggable":"^4.4.6","react-fast-marquee":"^1.6.2","react-highlight-words":"^0.20.0","react-infinite-scroll-component":"^6.1.0","react-resizable":"^3.0.5","react-router-dom":"^6.20.0","react-sticky-box":"^2.0.5","regenerator-runtime":"^0.14.0",remark:"^15.0.1","remark-cli":"^12.0.0","remark-lint":"^9.1.2","remark-lint-no-undefined-references":"^4.2.1","remark-preset-lint-recommended":"^6.1.3",runes2:"^1.1.3",semver:"^7.5.4","simple-git":"^3.21.0","size-limit":"^11.0.0",stylelint:"^15.11.0","stylelint-config-rational-order":"^0.1.2","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.1.0",sylvanas:"^0.6.1",terser:"^5.24.0",tsx:"^4.6.0",typedoc:"^0.25.4",typescript:"~5.3.0","vanilla-jsoneditor":"^0.20.0","vanilla-tilt":"^1.8.1",webpack:"^5.89.0","webpack-bundle-analyzer":"^4.10.1","xhr-mock":"^2.5.1","@ant-design/colors":"^7.0.0","@ant-design/cssinjs":"^1.18.1","@ant-design/icons":"^5.2.6","@ant-design/react-slick":"~1.0.2","@babel/runtime":"^7.23.4","@ctrl/tinycolor":"^3.6.1","@rc-component/color-picker":"~1.4.1","@rc-component/mutate-observer":"^1.1.0","@rc-component/tour":"~1.11.1","@rc-component/trigger":"^1.18.2",classnames:"^2.3.2","copy-to-clipboard":"^3.3.3",dayjs:"^1.11.1","qrcode.react":"^3.1.0","rc-cascader":"~3.20.0","rc-checkbox":"~3.1.0","rc-collapse":"~3.7.2","rc-dialog":"~9.3.4","rc-drawer":"~6.5.2","rc-dropdown":"~4.1.0","rc-field-form":"~1.41.0","rc-image":"~7.5.1","rc-input":"~1.3.6","rc-input-number":"~8.4.0","rc-mentions":"~2.9.1","rc-menu":"~9.12.4","rc-motion":"^2.9.0","rc-notification":"~5.3.0","rc-pagination":"~4.0.2","rc-picker":"~3.14.6","rc-progress":"~3.5.1","rc-rate":"~2.12.0","rc-resize-observer":"^1.4.0","rc-segmented":"~2.2.2","rc-select":"~14.10.0","rc-slider":"~10.5.0","rc-steps":"~6.0.1","rc-switch":"~4.1.0","rc-table":"~7.36.0","rc-tabs":"~12.14.1","rc-textarea":"~1.5.3","rc-tooltip":"~6.1.2","rc-tree":"~5.8.2","rc-tree-select":"~5.15.0","rc-upload":"~4.3.5","rc-util":"^5.38.1","scroll-into-view-if-needed":"^3.1.0","throttle-debounce":"^5.0.0"},jsx:`import React, { useState } from 'react';
import { Button, ConfigProvider, Descriptions, Radio } from 'antd';
const borderedItems = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Time',
    children: '18:00:00',
  },
  {
    key: '4',
    label: 'Amount',
    children: '$80.00',
  },
  {
    key: '5',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '6',
    label: 'Official',
    children: '$60.00',
  },
  {
    key: '7',
    label: 'Config Info',
    children: (
      <>
        Data disk type: MongoDB
        <br />
        Database version: 3.4
        <br />
        Package: dds.mongo.mid
        <br />
        Storage space: 10 GB
        <br />
        Replication factor: 3
        <br />
        Region: East China 1
        <br />
      </>
    ),
  },
];
const items = [
  {
    key: '1',
    label: 'Product',
    children: 'Cloud Database',
  },
  {
    key: '2',
    label: 'Billing',
    children: 'Prepaid',
  },
  {
    key: '3',
    label: 'Time',
    children: '18:00:00',
  },
  {
    key: '4',
    label: 'Amount',
    children: '$80.00',
  },
  {
    key: '5',
    label: 'Discount',
    children: '$20.00',
  },
  {
    key: '6',
    label: 'Official',
    children: '$60.00',
  },
];
const App = () => {
  const [size, setSize] = useState('default');
  const onChange = (e) => {
    console.log('size checked', e.target.value);
    setSize(e.target.value);
  };
  return (
    <ConfigProvider
      theme={{
        components: {
          Descriptions: {
            labelBg: 'red',
            titleColor: 'red',
            titleMarginBottom: 2,
            itemPaddingBottom: 8,
            colonMarginRight: 10,
            colonMarginLeft: 20,
            contentColor: 'green',
            extraColor: 'blue',
          },
        },
      }}
    >
      <div>
        <Radio.Group onChange={onChange} value={size}>
          <Radio value="default">default</Radio>
          <Radio value="middle">middle</Radio>
          <Radio value="small">small</Radio>
        </Radio.Group>
        <br />
        <br />
        <Descriptions
          bordered
          title="Custom Size"
          size={size}
          extra={<div>extra color: blue</div>}
          items={borderedItems}
        />
        <br />
        <br />
        <Descriptions
          title="Custom Size"
          size={size}
          extra={<Button type="primary">Edit</Button>}
          items={items}
        />
      </div>
    </ConfigProvider>
  );
};
export default App;
`,description:"<p>Component Token Debug.</p>"}}]}),(0,e.jsxs)("div",{className:"markdown",children:[(0,e.jsxs)("h2",{id:"api",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#api",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"API"]}),(0,e.jsxs)("p",{children:[t[3].value,(0,e.jsx)(r.Z,{to:"/docs/react/common-props",sourceType:"Link",children:t[4].value})]}),(0,e.jsxs)("h3",{id:"descriptions",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#descriptions",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Descriptions"]}),(0,e.jsxs)(i.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[5].value}),(0,e.jsx)("th",{children:t[6].value}),(0,e.jsx)("th",{children:t[7].value}),(0,e.jsx)("th",{children:t[8].value}),(0,e.jsx)("th",{children:t[9].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[10].value}),(0,e.jsx)("td",{children:t[11].value}),(0,e.jsx)("td",{children:t[12].value}),(0,e.jsx)("td",{children:t[13].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[14].value}),(0,e.jsxs)("td",{children:[t[15].value,(0,e.jsx)("code",{children:t[16].value}),t[17].value]}),(0,e.jsx)("td",{children:t[18].value}),(0,e.jsx)("td",{children:t[19].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[20].value}),(0,e.jsxs)("td",{children:[t[21].value,(0,e.jsx)("code",{children:t[22].value}),t[23].value,(0,e.jsx)("code",{children:t[24].value}),t[25].value,(0,e.jsx)("code",{children:t[26].value}),t[27].value]}),(0,e.jsxs)("td",{children:[t[28].value,(0,e.jsx)(r.Z,{href:"https://github.com/ant-design/ant-design/blob/84ca0d23ae52e4f0940f20b0e22eabe743f90dca/components/descriptions/index.tsx#L111C21-L111C56",sourceType:"a",children:t[29].value})]}),(0,e.jsx)("td",{children:t[30].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[31].value}),(0,e.jsx)("td",{children:t[32].value}),(0,e.jsx)("td",{children:t[33].value}),(0,e.jsx)("td",{children:t[34].value}),(0,e.jsx)("td",{children:t[35].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[36].value}),(0,e.jsx)("td",{children:t[37].value}),(0,e.jsx)("td",{children:t[38].value}),(0,e.jsx)("td",{children:t[39].value}),(0,e.jsx)("td",{children:t[40].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[41].value}),(0,e.jsx)("td",{children:t[42].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)(r.Z,{to:"#descriptionitem",sourceType:"Link",children:t[43].value}),t[44].value]}),(0,e.jsx)("td",{children:t[45].value}),(0,e.jsx)("td",{children:t[46].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[47].value}),(0,e.jsx)("td",{children:t[48].value}),(0,e.jsx)("td",{children:t[49].value}),(0,e.jsx)("td",{children:t[50].value}),(0,e.jsx)("td",{children:t[51].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[52].value}),(0,e.jsx)("td",{children:t[53].value}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[54].value}),t[55].value,(0,e.jsx)("code",{children:t[56].value})]}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[57].value})}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[58].value}),(0,e.jsxs)("td",{children:[t[59].value,(0,e.jsx)("code",{children:t[60].value}),t[61].value,(0,e.jsx)("code",{children:t[62].value}),t[63].value]}),(0,e.jsxs)("td",{children:[(0,e.jsx)("code",{children:t[64].value}),t[65].value,(0,e.jsx)("code",{children:t[66].value}),t[67].value,(0,e.jsx)("code",{children:t[68].value})]}),(0,e.jsx)("td",{children:t[69].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[70].value}),(0,e.jsx)("td",{children:t[71].value}),(0,e.jsx)("td",{children:t[72].value}),(0,e.jsx)("td",{children:t[73].value}),(0,e.jsx)("td",{})]})]})]}),(0,e.jsxs)("h3",{id:"descriptionitem",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#descriptionitem",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"DescriptionItem"]}),(0,e.jsxs)(i.Z,{className:"component-api-table",children:[(0,e.jsx)("thead",{children:(0,e.jsxs)("tr",{children:[(0,e.jsx)("th",{children:t[74].value}),(0,e.jsx)("th",{children:t[75].value}),(0,e.jsx)("th",{children:t[76].value}),(0,e.jsx)("th",{children:t[77].value}),(0,e.jsx)("th",{children:t[78].value})]})}),(0,e.jsxs)("tbody",{children:[(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[79].value}),(0,e.jsx)("td",{children:t[80].value}),(0,e.jsx)("td",{children:t[81].value}),(0,e.jsx)("td",{children:t[82].value}),(0,e.jsx)("td",{children:t[83].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[84].value}),(0,e.jsx)("td",{children:t[85].value}),(0,e.jsx)("td",{children:t[86].value}),(0,e.jsx)("td",{children:t[87].value}),(0,e.jsx)("td",{})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[88].value}),(0,e.jsx)("td",{children:t[89].value}),(0,e.jsx)("td",{children:t[90].value}),(0,e.jsx)("td",{children:t[91].value}),(0,e.jsx)("td",{children:t[92].value})]}),(0,e.jsxs)("tr",{children:[(0,e.jsx)("td",{children:t[93].value}),(0,e.jsx)("td",{children:t[94].value}),(0,e.jsxs)("td",{children:[t[95].value,(0,e.jsx)(r.Z,{to:"/components/grid#col",sourceType:"Link",children:t[96].value})]}),(0,e.jsx)("td",{children:t[97].value}),(0,e.jsx)("td",{children:(0,e.jsx)("code",{children:t[98].value})})]})]})]}),(0,e.jsx)("blockquote",{children:(0,e.jsxs)("p",{children:[t[99].value,(0,e.jsx)("code",{children:t[100].value}),t[101].value,(0,e.jsx)("code",{children:t[102].value}),t[103].value,(0,e.jsx)("code",{children:t[104].value}),t[105].value]})}),(0,e.jsxs)("h2",{id:"design-token",children:[(0,e.jsx)(r.Z,{"aria-hidden":"true",tabIndex:"-1",href:"#design-token",sourceType:"a",children:(0,e.jsx)("span",{className:"icon icon-link"})}),"Design Token"]})]}),(0,e.jsx)(c.Z,{component:"Descriptions"})]})})}s.default=d}}]);
